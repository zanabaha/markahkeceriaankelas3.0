
import React, { useState, useEffect } from 'react';
import { Classroom } from '../types';
import { getAITips } from '../services/geminiService';

interface AISuggestionsProps {
  classrooms: Classroom[];
}

const AISuggestions: React.FC<AISuggestionsProps> = ({ classrooms }) => {
  const [selectedClassId, setSelectedClassId] = useState<string>(classrooms[0]?.id || '');
  const [loading, setLoading] = useState(false);
  const [data, setData] = useState<{ analysis: string, tips: { kriteria: string, cadangan: string }[], motivation: string } | null>(null);

  const fetchTips = async () => {
    const selected = classrooms.find(c => c.id === selectedClassId);
    if (!selected || selected.scores.length === 0) {
      setData(null);
      return;
    }

    setLoading(true);
    const result = await getAITips(selected);
    setData(result);
    setLoading(false);
  };

  useEffect(() => {
    if (selectedClassId) {
      fetchTips();
    }
  }, [selectedClassId]);

  return (
    <div className="space-y-6">
      <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h3 className="text-lg font-bold text-slate-800">Analisis Pintar Gemini AI</h3>
          <p className="text-sm text-slate-500">Cadangan dijana berdasarkan trend markah terkini kelas.</p>
        </div>
        <select 
          className="p-3 border border-slate-200 rounded-xl bg-slate-50 font-medium outline-none focus:ring-2 focus:ring-indigo-500"
          value={selectedClassId}
          onChange={(e) => setSelectedClassId(e.target.value)}
        >
          {classrooms.map(c => (
            <option key={c.id} value={c.id}>{c.name}</option>
          ))}
        </select>
      </div>

      {loading ? (
        <div className="flex flex-col items-center justify-center p-24 bg-white rounded-3xl border border-slate-100">
          <div className="relative">
            <div className="animate-spin rounded-full h-16 w-16 border-t-4 border-indigo-600 border-r-4 border-r-transparent"></div>
            <div className="absolute inset-0 flex items-center justify-center">
               <div className="w-8 h-8 bg-indigo-100 rounded-full animate-pulse"></div>
            </div>
          </div>
          <p className="mt-6 text-slate-500 font-bold text-lg animate-pulse">AI sedang merangka strategi keceriaan...</p>
        </div>
      ) : data ? (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-1 space-y-6">
            <div className="bg-white p-8 rounded-3xl border border-slate-100 shadow-sm relative overflow-hidden group">
              <div className="absolute -right-4 -top-4 w-24 h-24 bg-indigo-50 rounded-full group-hover:scale-110 transition-transform"></div>
              <h3 className="text-xl font-bold mb-4 relative text-indigo-900">Rumusan Analisis</h3>
              <p className="text-slate-600 leading-relaxed relative">
                {data.analysis}
              </p>
            </div>

            <div className="bg-gradient-to-br from-indigo-600 to-violet-700 p-8 rounded-3xl text-white shadow-xl shadow-indigo-100">
              <h3 className="text-xl font-bold mb-4 flex items-center space-x-2">
                <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 20 20">
                   <path d="M11 3a1 1 0 10-2 0v1a1 1 0 102 0V3zM15.657 5.757a1 1 0 00-1.414-1.414l-.707.707a1 1 0 001.414 1.414l.707-.707zM18 10a1 1 0 01-1 1h-1a1 1 0 110-2h1a1 1 0 011 1zM5.05 6.464A1 1 0 106.464 5.05l-.707-.707a1 1 0 00-1.414 1.414l.707.707zM5 10a1 1 0 01-1 1H3a1 1 0 110-2h1a1 1 0 011 1zM8 16v-1a1 1 0 112 0v1a1 1 0 11-2 0zM13.536 14.95a1 1 0 010-1.414l.707-.707a1 1 0 011.414 1.414l-.707.707a1 1 0 01-1.414 0zM6.464 14.95a1 1 0 01-1.414 0l-.707-.707a1 1 0 011.414-1.414l.707.707a1 1 0 010 1.414z" />
                </svg>
                <span>Mesej Motivasi</span>
              </h3>
              <p className="italic text-indigo-50 opacity-90 text-lg leading-relaxed">
                "{data.motivation}"
              </p>
            </div>
          </div>
          
          <div className="lg:col-span-2 space-y-4">
            <h3 className="text-xl font-bold text-slate-800 flex items-center space-x-2">
              <span className="w-2 h-8 bg-indigo-600 rounded-full"></span>
              <span>Pelan Tindakan Disyorkan</span>
            </h3>
            {data.tips.map((tip, idx) => (
              <div key={idx} className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm flex items-start space-x-4 hover:shadow-md transition-shadow">
                <div className="bg-indigo-600 text-white w-10 h-10 rounded-xl flex items-center justify-center shrink-0 font-bold shadow-lg shadow-indigo-100">
                  {idx + 1}
                </div>
                <div>
                  <h4 className="font-bold text-slate-900 text-lg mb-1">{tip.kriteria}</h4>
                  <p className="text-slate-600 leading-relaxed">{tip.cadangan}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      ) : (
        <div className="p-20 text-center bg-white rounded-3xl border border-dashed border-slate-200">
           <p className="text-slate-400 font-medium">Tiada data markah ditemui untuk kelas ini. Sila masukkan markah terlebih dahulu.</p>
        </div>
      )}
    </div>
  );
};

export default AISuggestions;
