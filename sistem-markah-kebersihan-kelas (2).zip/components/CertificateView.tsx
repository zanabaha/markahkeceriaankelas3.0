
import React, { useRef, useState, useEffect } from 'react';
import html2canvas from 'html2canvas';
import { jsPDF } from 'jspdf';
import { Download, Image as ImageIcon, Upload, Check, Trash2, Sparkles, X, RefreshCw } from 'lucide-react';
import { StorageService } from '../services/storage';

interface CertificateViewProps {
  schoolName: string;
  className: string;
  teacherName: string;
  score: number;
  week: number;
  category: string;
  onClose: () => void;
}

const PRESET_TEMPLATES = [
  { id: 1, url: 'https://i.ibb.co/68v8z9f/template-1.png', label: 'Star Excellence' },
  { id: 2, url: 'https://i.ibb.co/vY6z7z9/template-2.png', label: 'Blue Ribbon' },
  { id: 3, url: 'https://i.ibb.co/yY6z7z9/template-3.png', label: 'Gold Trophy' },
  { id: 4, url: 'https://placehold.co/1123x794/indigo/white?text=TAPAK+DESIGN+GUIDE\n(Guna+Saiz+Ini+Di+Canva)', label: 'Tapak Design (Guide)' }
];

const CertificateView: React.FC<CertificateViewProps> = ({ schoolName, className, teacherName, score, week, category, onClose }) => {
  const certificateRef = useRef<HTMLDivElement>(null);
  const [settings] = useState(StorageService.getCertSettings());
  const [isPrinting, setIsPrinting] = useState(false);
  
  // Use custom background from settings if available, else default to first preset
  const [selectedTemplate, setSelectedTemplate] = useState(settings.customCertificateUrl || PRESET_TEMPLATES[0].url);

  const downloadAsPDF = async () => {
    if (!certificateRef.current) return;
    setIsPrinting(true);

    // Small delay to ensure scale-100 is applied
    setTimeout(async () => {
      try {
        const canvas = await html2canvas(certificateRef.current!, { 
          scale: 3,
          useCORS: true,
          logging: false,
          backgroundColor: '#ffffff'
        });
        const imgData = canvas.toDataURL('image/png');
        const pdf = new jsPDF('l', 'px', [canvas.width, canvas.height]);
        pdf.addImage(imgData, 'PNG', 0, 0, canvas.width, canvas.height);
        pdf.save(`SIJIL_CERIA_${className.replace(/\s+/g, '_')}.pdf`);
      } catch (err) {
        console.error("PDF generation failed:", err);
        alert("Gagal menjana PDF. Sila cuba lagi.");
      } finally {
        setIsPrinting(true); // Keep it true for a moment or reset
        setIsPrinting(false);
      }
    }, 100);
  };

  return (
    <div className="flex flex-col lg:flex-row gap-8 p-6 lg:p-10 max-h-[90vh] overflow-y-auto no-scrollbar">
      {/* Sidebar: Template Selection */}
      <div className="lg:w-80 space-y-6 no-print">
        <div className="bg-white/10 backdrop-blur-xl p-6 rounded-[32px] border border-white/10">
          <h3 className="text-white font-black text-xs uppercase tracking-widest mb-6 flex items-center gap-2">
            <ImageIcon size={16} className="text-indigo-400" />
            Pilih Templat Sijil
          </h3>
          
          <div className="grid grid-cols-2 gap-3 mb-6">
            {/* Show custom template if exists in settings */}
            {settings.customCertificateUrl && (
              <button
                onClick={() => setSelectedTemplate(settings.customCertificateUrl!)}
                className={`relative aspect-[1.4/1] rounded-xl overflow-hidden border-2 transition-all ${
                  selectedTemplate === settings.customCertificateUrl ? 'border-amber-400 ring-4 ring-amber-400/20' : 'border-white/10 grayscale hover:grayscale-0'
                }`}
              >
                <img src={settings.customCertificateUrl} className="w-full h-full object-cover" />
                {selectedTemplate === settings.customCertificateUrl && (
                  <div className="absolute inset-0 bg-amber-600/20 flex items-center justify-center">
                    <Check className="text-white" size={24} />
                  </div>
                )}
                <div className="absolute bottom-0 left-0 right-0 bg-amber-500 text-[8px] font-black text-white text-center py-1">CUSTOM</div>
              </button>
            )}

            {PRESET_TEMPLATES.map((t) => (
              <div key={t.id} className="relative group/item">
                <button
                  onClick={() => setSelectedTemplate(t.url)}
                  className={`w-full relative aspect-[1.4/1] rounded-xl overflow-hidden border-2 transition-all ${
                    selectedTemplate === t.url ? 'border-indigo-500 ring-4 ring-indigo-500/20' : 'border-white/10 grayscale hover:grayscale-0'
                  }`}
                >
                  <img src={t.url} className="w-full h-full object-cover" alt={t.label} />
                  {selectedTemplate === t.url && (
                    <div className="absolute inset-0 bg-indigo-600/20 flex items-center justify-center">
                      <Check className="text-white" size={24} />
                    </div>
                  )}
                </button>
                <button 
                  onClick={(e) => {
                    e.stopPropagation();
                    const link = document.createElement('a');
                    link.href = t.url;
                    link.download = `Template_${t.label.replace(/\s+/g, '_')}.png`;
                    link.target = "_blank";
                    document.body.appendChild(link);
                    link.click();
                    document.body.removeChild(link);
                  }}
                  className="absolute top-2 right-2 p-2 bg-white/90 text-indigo-600 rounded-lg opacity-0 group-hover/item:opacity-100 transition-opacity shadow-lg hover:bg-white"
                  title="Muat Turun Template Kosong"
                >
                  <Download size={12} />
                </button>
              </div>
            ))}
          </div>
          
          <p className="text-[9px] font-bold text-indigo-200/50 uppercase text-center leading-relaxed">
            Muat naik template Canva (Custom) anda di tab Admin &gt; Identiti &amp; Template
          </p>
        </div>

        <div className="space-y-3">
          <button 
            onClick={downloadAsPDF}
            disabled={isPrinting}
            className="w-full bg-indigo-600 text-white py-5 rounded-[24px] font-black text-xs uppercase tracking-[0.2em] shadow-2xl shadow-indigo-500/30 hover:bg-indigo-500 transition-all flex items-center justify-center gap-3 active:scale-95 disabled:opacity-50"
          >
            {isPrinting ? <RefreshCw className="animate-spin" size={18} /> : <Download size={18} />}
            {isPrinting ? 'SEDANG MENJANA...' : 'MUAT TURUN PDF'}
          </button>
          <button 
            onClick={onClose}
            className="w-full bg-white/5 text-white/60 py-4 rounded-[24px] font-black text-[10px] uppercase tracking-[0.2em] hover:bg-white/10 transition-all"
          >
            Tutup Paparan
          </button>
        </div>
      </div>

      {/* Certificate Preview Container */}
      <div className="flex-1 flex flex-col items-center">
        <div className="bg-white/5 p-4 rounded-[40px] border border-white/10 shadow-2xl">
          <div className={`${isPrinting ? 'scale-100' : 'scale-[0.4] sm:scale-[0.5] md:scale-[0.7] lg:scale-[0.8] xl:scale-[1]'} origin-top transition-transform`}>
            <div 
              ref={certificateRef}
              className="w-[1123px] h-[794px] bg-white relative overflow-hidden shadow-2xl"
              style={{
                backgroundImage: `url(${selectedTemplate})`,
                backgroundSize: 'cover',
                backgroundPosition: 'center'
              }}
            >
              {/* Certificate Content Overlay */}
              <div className="absolute inset-0 flex flex-col items-center text-center px-32 pointer-events-none">
                
                {/* NAMA KELAS (System) */}
                <div className="mt-[340px] w-full">
                   <h2 className="text-7xl font-black text-[#1e1b4b] uppercase tracking-tight drop-shadow-md leading-none">
                     {className}
                   </h2>
                </div>

                {/* KATEGORI & MINGGU (System) */}
                <div className="mt-[20px] w-full">
                   <p className="text-xl font-black text-slate-600 uppercase tracking-[0.3em]">
                     {category.toUpperCase()} • MINGGU {week}
                   </p>
                </div>

                {/* MARKAH - GRED - PERATUS (System) */}
                <div className="mt-[60px] w-full">
                   <div className="inline-flex items-center gap-8 bg-indigo-950/5 px-12 py-4 rounded-[30px] border border-indigo-950/10">
                      <p className="text-5xl font-black text-indigo-950 tracking-tighter">
                        {score}%
                      </p>
                      <div className="w-1 h-10 bg-indigo-950/20"></div>
                      <p className="text-4xl font-black text-indigo-950">GRED A</p>
                   </div>
                </div>

                {/* TARIKH & BINTANG (System) - Bottom Left */}
                <div className="absolute bottom-[100px] left-[80px] text-left">
                   <div className="flex items-center gap-2 mb-1">
                      <Sparkles size={12} className="text-amber-400" fill="currentColor" />
                      <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Tarikh Penganugerahan</p>
                   </div>
                   <p className="text-lg font-black text-indigo-900 leading-none">
                     {new Date().toLocaleDateString('ms-MY', { day: 'numeric', month: 'long', year: 'numeric' })}
                   </p>
                </div>

                {/* TANDATANGAN PENGETUA (System) - Bottom Right */}
                <div className="absolute bottom-[100px] right-[80px] text-right">
                   <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Tandatangan Pengetua</p>
                   <div className="h-12 flex items-end justify-end">
                      <p className="text-lg font-black text-indigo-900 underline decoration-2 underline-offset-4">
                        PENGURUSAN SEKOLAH
                      </p>
                   </div>
                </div>

                {/* Requested Watermark */}
                <div className="absolute bottom-6 left-0 right-0 opacity-20">
                   <p className="text-[8px] font-black text-indigo-950 uppercase tracking-[0.5em]">designbycikguzana</p>
                </div>
              </div>
            </div>
          </div>
        </div>
        <p className="mt-6 text-white/40 text-[10px] font-black uppercase tracking-[0.3em]">Paparan di atas adalah pralihat (Preview). Muat turun PDF untuk resolusi penuh.</p>
      </div>
    </div>
  );
};

export default CertificateView;
