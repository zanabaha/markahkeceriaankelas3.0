
import React, { useState, useRef } from 'react';
import { Classroom } from '../types';
import { GoogleGenAI } from "@google/genai";

interface ManagementViewProps {
  classrooms: Classroom[];
  onUpdateClassrooms: (updated: Classroom[]) => void;
}

const ManagementView: React.FC<ManagementViewProps> = ({ classrooms, onUpdateClassrooms }) => {
  const [selectedClassId, setSelectedClassId] = useState(classrooms[0]?.id || '');
  const [rawText, setRawText] = useState('');
  const [isCleaning, setIsCleaning] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const activeClass = classrooms.find(c => c.id === selectedClassId);

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      const text = e.target?.result as string;
      setRawText(text);
    };
    reader.readAsText(file);
  };

  const cleanWithAI = async () => {
    if (!rawText.trim()) return;
    setIsCleaning(true);
    
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const prompt = `
      Anda adalah pembantu pengurusan data sekolah. 
      Tugas: Ambil teks mentah berikut dan bersihkan menjadi senarai nama murid yang teratur.
      - Buang nombor (cth: 1., 2.)
      - Baiki ejaan huruf besar (cth: ahmad -> Ahmad)
      - Buang simbol yang tidak perlu.
      - Berikan jawapan dalam format JSON array string sahaja.
      
      Teks Mentah:
      ${rawText}
    `;

    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: prompt,
        config: {
          responseMimeType: "application/json",
        }
      });
      
      const text = response.text;
      const cleaned = JSON.parse(text || '[]');
      if (Array.isArray(cleaned)) {
        setRawText(cleaned.join('\n'));
      }
    } catch (error) {
      console.error("AI Cleaning failed", error);
      alert("Gagal membersihkan data secara automatik. Sila bersihkan secara manual.");
    } finally {
      setIsCleaning(false);
    }
  };

  const handleSaveStudents = () => {
    const students = rawText.split('\n').map(s => s.trim()).filter(s => s.length > 0);
    const updated = classrooms.map(c => {
      if (c.id === selectedClassId) {
        return { ...c, students };
      }
      return c;
    });
    onUpdateClassrooms(updated);
    alert(`Berjaya memuat naik ${students.length} nama murid untuk kelas ${activeClass?.name}`);
    setRawText('');
  };

  const handleUpdateTeacher = (classId: string, name: string) => {
    const updated = classrooms.map(c => {
      if (c.id === classId) {
        return { ...c, teacher: name };
      }
      return c;
    });
    onUpdateClassrooms(updated);
  };

  return (
    <div className="space-y-8 pb-20">
      {/* Teacher Management Section */}
      <section className="bg-white p-8 rounded-3xl border border-slate-100 shadow-sm">
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center space-x-3">
            <div className="bg-amber-100 text-amber-600 p-2 rounded-xl">
               <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" /></svg>
            </div>
            <div>
              <h3 className="text-xl font-black text-slate-800">Kemaskini Guru Kelas</h3>
              <p className="text-sm text-slate-500">Uruskan guru yang bertanggungjawab bagi setiap kelas.</p>
            </div>
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {classrooms.map(c => (
            <div key={c.id} className="p-5 bg-slate-50 rounded-2xl border border-slate-100 group hover:border-amber-200 transition-all">
              <label className="text-[10px] font-black text-slate-400 uppercase mb-2 block tracking-widest">{c.name}</label>
              <div className="relative">
                <input 
                  type="text"
                  value={c.teacher}
                  onChange={(e) => handleUpdateTeacher(c.id, e.target.value)}
                  className="w-full bg-white px-4 py-3 rounded-xl border border-transparent group-hover:border-slate-200 font-bold text-slate-700 outline-none focus:ring-2 focus:ring-amber-500 transition-all"
                  placeholder="Nama Guru"
                />
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Student Management Section */}
      <section className="bg-white p-8 rounded-3xl border border-slate-100 shadow-sm">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
          <div className="flex items-center space-x-3">
            <div className="bg-indigo-100 text-indigo-600 p-2 rounded-xl">
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" /></svg>
            </div>
            <div>
              <h3 className="text-xl font-black text-slate-800">Muat Naik Senarai Murid</h3>
              <p className="text-sm text-slate-500">Gunakan format barisan atau muat naik fail teks.</p>
            </div>
          </div>
          
          <div className="flex flex-wrap gap-2">
            <input 
              type="file" 
              accept=".txt,.csv" 
              className="hidden" 
              ref={fileInputRef} 
              onChange={handleFileUpload}
            />
            <button 
              onClick={() => fileInputRef.current?.click()}
              className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl transition-all flex items-center space-x-2"
            >
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" /></svg>
              <span>Muat Naik Fail</span>
            </button>
            <select 
              value={selectedClassId}
              onChange={(e) => setSelectedClassId(e.target.value)}
              className="p-3 bg-indigo-50 border border-indigo-100 rounded-xl font-bold text-indigo-900 outline-none focus:ring-2 focus:ring-indigo-500 text-xs"
            >
              {classrooms.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
            </select>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <label className="text-xs font-black text-slate-400 uppercase tracking-widest">Input Senarai Nama</label>
              <button 
                onClick={cleanWithAI}
                disabled={isCleaning || !rawText}
                className="text-[10px] font-black bg-indigo-600 text-white px-3 py-1.5 rounded-lg hover:bg-indigo-700 flex items-center space-x-1.5 disabled:opacity-50 shadow-sm"
              >
                {isCleaning ? (
                   <span className="animate-pulse">AI sedang bekerja...</span>
                ) : (
                  <>
                    <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>
                    <span>SMART CLEAN (AI)</span>
                  </>
                )}
              </button>
            </div>
            <textarea 
              value={rawText}
              onChange={(e) => setRawText(e.target.value)}
              placeholder="Contoh:&#10;1. Ahmad Ali&#10;2. Siti Aminah&#10;3. Chong Wei"
              className="w-full h-72 p-5 bg-slate-50 border border-slate-200 rounded-2xl outline-none focus:ring-2 focus:ring-indigo-500 font-mono text-sm leading-relaxed"
            />
            <button 
              onClick={handleSaveStudents}
              disabled={!rawText.trim()}
              className="w-full py-4 bg-indigo-600 text-white font-black rounded-2xl hover:bg-indigo-700 transition-all shadow-xl shadow-indigo-100 disabled:bg-slate-200 disabled:shadow-none"
            >
              Simpan Senarai Nama
            </button>
          </div>

          <div className="bg-slate-50 rounded-2xl p-6 border border-dashed border-slate-200 flex flex-col">
            <div className="flex items-center justify-between mb-6">
              <h4 className="font-bold text-slate-800">Senarai Nama Wujud</h4>
              <span className="bg-white border border-slate-100 px-3 py-1 rounded-full text-[10px] font-black text-indigo-600">
                {activeClass?.students.length || 0} MURID
              </span>
            </div>
            <div className="flex-1 space-y-2 overflow-y-auto max-h-[340px] pr-2 custom-scrollbar">
              {activeClass?.students && activeClass.students.length > 0 ? activeClass.students.map((name, i) => (
                <div key={i} className="flex items-center space-x-3 bg-white p-3 rounded-xl border border-slate-100 hover:border-indigo-100 transition-colors">
                  <span className="w-6 h-6 flex items-center justify-center text-[10px] font-black text-indigo-400 bg-indigo-50 rounded-lg">{i + 1}</span>
                  <span className="text-xs font-bold text-slate-700 uppercase tracking-tight">{name}</span>
                </div>
              )) : (
                <div className="h-full flex flex-col items-center justify-center text-slate-400 text-sm italic space-y-4">
                  <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center">
                    <svg className="w-8 h-8 text-slate-300" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" /></svg>
                  </div>
                  <p>Tiada murid didaftarkan.</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default ManagementView;
