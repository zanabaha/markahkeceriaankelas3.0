
import React, { useState } from 'react';
import { Classroom } from '../types';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

interface HistoryViewProps {
  classrooms: Classroom[];
}

const HistoryView: React.FC<HistoryViewProps> = ({ classrooms }) => {
  const [selectedId, setSelectedId] = useState(classrooms[0]?.id || '');
  const classroom = classrooms.find(c => c.id === selectedId);

  if (!classroom) return <div className="p-8 text-center text-slate-400">Tiada data kelas ditemui.</div>;

  const chartData = classroom.scores.map(s => ({
    week: `Minggu ${s.week}`,
    total: s.total,
    ...s.marks
  }));

  return (
    <div className="space-y-6">
      <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h3 className="text-xl font-bold text-slate-800">{classroom.name}</h3>
          <p className="text-slate-500">Guru: {classroom.teacher}</p>
        </div>
        <select 
          value={selectedId} 
          onChange={(e) => setSelectedId(e.target.value)}
          className="p-3 border border-slate-200 rounded-xl bg-slate-50 font-medium outline-none focus:ring-2 focus:ring-indigo-500"
        >
          {classrooms.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
        </select>
      </div>

      <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
        <h4 className="text-lg font-bold mb-6">Trend Markah Keseluruhan</h4>
        <div className="h-72">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={chartData}>
              <defs>
                <linearGradient id="colorTotal" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#6366f1" stopOpacity={0.1}/>
                  <stop offset="95%" stopColor="#6366f1" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
              <XAxis dataKey="week" stroke="#94a3b8" fontSize={12} tickLine={false} axisLine={false} />
              <YAxis stroke="#94a3b8" fontSize={12} tickLine={false} axisLine={false} domain={[0, 100]} />
              <Tooltip 
                contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
              />
              <Area type="monotone" dataKey="total" stroke="#6366f1" strokeWidth={3} fillOpacity={1} fill="url(#colorTotal)" />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {classroom.scores.slice().reverse().map((score, i) => (
          <div key={i} className="bg-white p-5 rounded-2xl border border-slate-100 shadow-sm hover:border-indigo-200 transition-colors">
            <div className="flex justify-between items-start mb-4">
              <div>
                <p className="text-xs font-bold text-indigo-500 uppercase tracking-wider">Minggu {score.week}</p>
                <p className="text-sm text-slate-400">{score.date}</p>
              </div>
              <div className="text-2xl font-black text-slate-800">{score.total}%</div>
            </div>
            <div className="space-y-2">
              {Object.entries(score.marks).map(([key, val]) => (
                <div key={key} className="flex justify-between text-xs">
                  <span className="capitalize text-slate-500">{key.replace(/([A-Z])/g, ' $1')}</span>
                  <span className="font-bold text-slate-700">{val}</span>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default HistoryView;
