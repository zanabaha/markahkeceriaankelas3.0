
import React, { useEffect, useState, useMemo } from 'react';
import { Home, ClipboardList, BarChart2, Award, Users, Download, Share2, Menu, Sparkles, X, FileText, Settings } from 'lucide-react';
import * as XLSX from 'xlsx';
import { Classroom, ViewType } from '../types';
import { StorageService } from '../services/storage';

interface NavbarProps {
  currentView: ViewType;
  onNavigate: (view: ViewType) => void;
  classrooms: Classroom[];
  schoolName: string;
}

const Navbar: React.FC<NavbarProps> = ({ currentView, onNavigate, classrooms, schoolName }) => {
  const settings = useMemo(() => StorageService.getCertSettings(), [currentView]);
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [isIOS, setIsIOS] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const isIosDevice = /iPad|iPhone|iPod/.test(navigator.userAgent) && !(window as any).MSStream;
    setIsIOS(isIosDevice);

    const handleBeforeInstallPrompt = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    return () => window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
  }, []);

  const handleExportExcel = () => {
    if (classrooms.length === 0) return alert('Tiada data untuk diexport');
    const rows: any[] = [];
    classrooms.forEach(cls => {
      cls.scores.forEach(score => {
        rows.push({
          'Minggu': score.week,
          'Tarikh': score.date,
          'Nama Kelas': cls.name,
          'Guru Kelas': cls.teacher,
          'Markah (%)': score.total
        });
      });
    });
    const ws = XLSX.utils.json_to_sheet(rows);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Laporan');
    XLSX.writeFile(wb, `Laporan_${schoolName}.xlsx`);
  };

  const menuItems: { id: ViewType; label: string; icon: any }[] = [
    { id: 'home', label: 'Laman Utama', icon: Home },
    { id: 'dashboard', label: 'Analisis', icon: BarChart2 },
    { id: 'scoring', label: 'Penilaian', icon: ClipboardList },
    { id: 'ranking', label: 'Ranking', icon: Award },
    { id: 'awards', label: 'Sijil Terbaik', icon: Award },
    { id: 'ai-tips', label: 'Laporan', icon: FileText },
    { id: 'management', label: 'Pengurusan', icon: Settings },
  ];

  return (
    <div className="bg-white/80 backdrop-blur-md border-b border-slate-100 sticky top-0 z-50 px-4 md:px-8 py-3 no-print">
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        <div className="flex items-center space-x-3 cursor-pointer" onClick={() => onNavigate('home')}>
          <button 
            onClick={(e) => { e.stopPropagation(); setIsMobileMenuOpen(!isMobileMenuOpen); }}
            className="md:hidden p-2 text-slate-600 hover:bg-slate-100 rounded-xl"
          >
            {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
          <div className="flex items-center space-x-2">
            <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center text-white shadow-lg shadow-indigo-100">
               <Sparkles size={20} fill="currentColor" />
            </div>
            <div className="hidden sm:block">
              <h1 className="text-sm font-black text-slate-800 tracking-tight leading-none uppercase truncate max-w-[150px]">{schoolName}</h1>
              <span className="text-[10px] font-black text-indigo-500 uppercase tracking-widest block">{settings.systemName}</span>
            </div>
          </div>
        </div>

        <nav className="hidden md:flex items-center space-x-1">
          {menuItems.map((item) => (
            <button
              key={item.id}
              onClick={() => onNavigate(item.id)}
              className={`flex items-center space-x-2 px-4 py-2.5 rounded-xl font-black text-[10px] uppercase tracking-widest transition-all ${
                currentView === item.id 
                ? 'bg-indigo-600 text-white shadow-lg' 
                : 'text-slate-500 hover:bg-slate-100 hover:text-indigo-600'
              }`}
            >
              <item.icon size={16} />
              <span>{item.label}</span>
            </button>
          ))}
        </nav>

        <div className="flex items-center space-x-2">
          {settings.reportsDriveUrl && (
            <a 
              href={settings.reportsDriveUrl} 
              target="_blank" 
              rel="noreferrer"
              className="flex items-center space-x-2 bg-indigo-50 text-indigo-600 px-4 py-2.5 rounded-xl font-black text-[10px] uppercase tracking-widest hover:bg-indigo-100 transition-all"
            >
              <FileText size={16} />
              <span className="hidden lg:inline">Drive Laporan</span>
            </a>
          )}
          <button onClick={handleExportExcel} className="flex items-center space-x-2 bg-emerald-600 hover:bg-emerald-700 text-white px-4 py-2.5 rounded-xl font-black text-[10px] uppercase tracking-widest shadow-lg transition-all active:scale-95">
            <Share2 size={16} />
            <span className="hidden sm:inline">Export</span>
          </button>
        </div>
      </div>

      {isMobileMenuOpen && (
        <div className="md:hidden absolute top-full left-0 right-0 bg-white border-b border-slate-100 p-4 space-y-2 shadow-2xl">
          {menuItems.map((item) => (
            <button
              key={item.id}
              onClick={() => { onNavigate(item.id); setIsMobileMenuOpen(false); }}
              className={`w-full flex items-center space-x-4 p-4 rounded-2xl font-black text-xs uppercase tracking-widest ${
                currentView === item.id ? 'bg-indigo-600 text-white' : 'text-slate-500'
              }`}
            >
              <item.icon size={18} />
              <span>{item.label}</span>
            </button>
          ))}
        </div>
      )}
    </div>
  );
};

export default Navbar;
