
import React, { useMemo, useState } from 'react';
import { Classroom } from '../types';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { StorageService } from '../services/storage';
import { AlertCircle, ArrowUpRight, TrendingUp } from 'lucide-react';

interface DashboardProps {
  classrooms: Classroom[];
}

const Dashboard: React.FC<DashboardProps> = ({ classrooms }) => {
  const settings = useMemo(() => StorageService.getCertSettings(), []);
  const records = useMemo(() => StorageService.getRecords(), []);
  const [currentSession, setCurrentSession] = useState<'Pagi' | 'Petang'>('Pagi');

  const filteredClassrooms = classrooms.filter(c => c.session === currentSession);
  
  // Data untuk ranking minggu terkini
  const latestData = filteredClassrooms.map(c => ({
    name: c.name,
    score: c.scores[c.scores.length - 1]?.total || 0,
    kebersihan: c.scores[c.scores.length - 1]?.marks.kebersihan || 0,
    lestari: c.scores[c.scores.length - 1]?.marks.lestari || 0,
  })).sort((a, b) => b.score - a.score);

  // Data untuk JUARA TAHUNAN (Jumlah Terkumpul)
  const yearlyRankings = filteredClassrooms.map(c => ({
    name: c.name,
    teacher: c.teacher,
    accumulatedScore: c.scores.reduce((sum, s) => sum + s.total, 0),
    avgScore: c.scores.length > 0 ? Math.round(c.scores.reduce((sum, s) => sum + s.total, 0) / c.scores.length) : 0,
    weeks: c.scores.length
  })).sort((a, b) => b.accumulatedScore - a.accumulatedScore);

  const stats = {
    totalClasses: filteredClassrooms.length,
    avgSchoolScore: Math.round(latestData.reduce((acc, curr) => acc + curr.score, 0) / (filteredClassrooms.length || 1)),
    topYearly: yearlyRankings[0]?.name || 'N/A'
  };

  const COLORS = ['#6366f1', '#818cf8', '#a5b4fc', '#c7d2fe', '#e0e7ff'];

  return (
    <div className="space-y-12">
      <div className="flex gap-2">
        {['Pagi', 'Petang'].map((id) => (
          <button 
            key={id} 
            onClick={() => setCurrentSession(id as any)} 
            className={`px-8 py-4 rounded-2xl font-black text-[10px] uppercase tracking-widest transition-all ${currentSession === id ? 'bg-indigo-600 text-white shadow-xl shadow-indigo-100' : 'bg-white text-slate-400 border border-slate-100'}`}
          >
            Analisis Sesi {id}
          </button>
        ))}
      </div>

      {/* Juara Tahunan (Hall of Fame) */}
      <section>
        <div className="flex items-center space-x-3 mb-8">
           <div className="bg-amber-100 text-amber-600 p-2 rounded-xl">
              <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 20 20"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" /></svg>
           </div>
           <h3 className="text-2xl font-black text-slate-800 tracking-tight uppercase">Juara Tahunan (Hall of Fame)</h3>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {yearlyRankings.slice(0, 3).map((rank, i) => {
            const themes = [
              { bg: 'bg-gradient-to-br from-amber-400 to-amber-600', text: 'text-amber-50', medal: '🥇' },
              { bg: 'bg-gradient-to-br from-slate-300 to-slate-500', text: 'text-slate-50', medal: '🥈' },
              { bg: 'bg-gradient-to-br from-orange-400 to-orange-600', text: 'text-orange-50', medal: '🥉' }
            ];
            const theme = themes[i];
            
            return (
              <div key={rank.name} className={`${theme.bg} p-8 rounded-[40px] shadow-2xl relative overflow-hidden transform hover:-translate-y-2 transition-all`}>
                 <div className="absolute top-0 right-0 p-4 opacity-10">
                    <span className="text-9xl font-black">{i + 1}</span>
                 </div>
                 <div className="relative z-10 text-center">
                    <span className="text-5xl mb-4 block">{theme.medal}</span>
                    <h4 className="text-2xl font-black text-white uppercase tracking-tight truncate">{rank.name}</h4>
                    <p className={`text-xs font-bold uppercase tracking-widest ${theme.text} mb-6`}>{rank.teacher}</p>
                    
                    <div className="bg-white/20 backdrop-blur-md rounded-3xl p-6 border border-white/20">
                       <p className="text-[10px] font-black uppercase tracking-widest text-white/70 mb-1">Markah Terkumpul</p>
                       <p className="text-4xl font-black text-white">{rank.accumulatedScore}</p>
                       <div className="w-12 h-1 bg-white/30 mx-auto my-3 rounded-full"></div>
                       <p className="text-[10px] font-bold text-white/80 uppercase">Purata: {rank.avgScore}% • {rank.weeks} Minggu</p>
                    </div>
                 </div>
              </div>
            );
          })}
          {yearlyRankings.length === 0 && (
             <div className="col-span-3 bg-white border border-slate-100 p-12 rounded-[40px] text-center italic text-slate-400 font-bold">
                Data sedang dikumpul... Sila masukkan markah mingguan.
             </div>
          )}
        </div>
      </section>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Weekly Performance Graph */}
        <div className="lg:col-span-2 bg-white p-10 rounded-[40px] shadow-sm border border-slate-100">
           <div className="flex items-center justify-between mb-10">
              <div>
                <h3 className="text-xl font-black text-slate-800">Prestasi Minggu Semasa</h3>
                <p className="text-sm text-slate-500 font-bold uppercase tracking-tighter opacity-60">Perbandingan peratusan minggu ini</p>
              </div>
              <div className="bg-indigo-600 text-white px-5 py-2 rounded-2xl text-[10px] font-black uppercase tracking-widest shadow-xl shadow-indigo-100">
                LIVE
              </div>
           </div>
           <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={latestData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fontSize: 10, fontWeight: 900, fill: '#64748b'}} />
                <YAxis domain={[0, 100]} axisLine={false} tickLine={false} tick={{fontSize: 10, fill: '#94a3b8'}} />
                <Tooltip 
                  cursor={{fill: '#f8fafc'}}
                  contentStyle={{ borderRadius: '24px', border: 'none', boxShadow: '0 25px 50px -12px rgb(0 0 0 / 0.15)', fontWeight: 'bold' }}
                />
                <Bar dataKey="score" radius={[12, 12, 0, 0]} name="Skor">
                  {latestData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Stats Summary Column */}
        <div className="space-y-6">
           <div className="bg-white p-8 rounded-[40px] border border-slate-100 shadow-sm flex items-center space-x-6">
              <div className="w-14 h-14 bg-indigo-50 text-indigo-600 rounded-2xl flex items-center justify-center shrink-0">
                 <svg className="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" /></svg>
              </div>
              <div>
                 <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Kelas Dinilai</p>
                 <p className="text-3xl font-black text-slate-800">{stats.totalClasses}</p>
              </div>
           </div>

           <div className="bg-indigo-600 p-8 rounded-[40px] shadow-2xl shadow-indigo-100 flex items-center space-x-6">
              <div className="w-14 h-14 bg-white/20 text-white rounded-2xl flex items-center justify-center shrink-0 backdrop-blur-md">
                 <svg className="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" /></svg>
              </div>
              <div>
                 <p className="text-[10px] font-black text-indigo-100/60 uppercase tracking-widest mb-1">Purata Sekolah</p>
                 <p className="text-3xl font-black text-white">{stats.avgSchoolScore}%</p>
              </div>
           </div>

           <div className="bg-white p-8 rounded-[40px] border border-slate-100 shadow-sm">
              <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-4 text-center">Inisiatif Hijau (Lestari)</p>
              <div className="flex items-center justify-center space-x-2">
                 <span className="text-4xl font-black text-emerald-500">↑ 8.4</span>
                 <span className="text-xs font-bold text-slate-400 uppercase">Skor</span>
              </div>
              <div className="mt-4 w-full h-1 bg-slate-100 rounded-full overflow-hidden">
                 <div className="h-full bg-emerald-500 rounded-full" style={{width: '65%'}}></div>
              </div>
           </div>
        </div>
      </div>

      {/* Analisis Markah Terperinci (Detailed Analysis) */}
      <section className="bg-white p-10 rounded-[40px] shadow-sm border border-slate-100 overflow-hidden">
        <div className="flex flex-col md:flex-row md:items-center justify-between mb-8 gap-4">
           <div>
              <h3 className="text-2xl font-black text-slate-800 tracking-tight uppercase">Analisis Markah Terperinci</h3>
              <p className="text-xs text-slate-400 font-bold uppercase tracking-widest mt-1">Semak markah setiap kriteria untuk penambahbaikan</p>
           </div>
           <div className="flex items-center gap-2 bg-amber-50 text-amber-700 px-4 py-2 rounded-xl border border-amber-100">
              <AlertCircle size={16} />
              <span className="text-[10px] font-black uppercase tracking-widest">Fokus pada markah rendah (merah)</span>
           </div>
        </div>

        <div className="overflow-x-auto -mx-10 px-10">
          <table className="w-full border-collapse">
            <thead>
              <tr className="border-b border-slate-100">
                <th className="py-6 text-left text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] pr-4">Kelas & Guru</th>
                <th className="py-6 text-center text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] px-4">Skor (%)</th>
                {settings.criteria.map(c => (
                  <th key={c.id} className="py-6 text-center text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] px-4 min-w-[100px]">
                    {c.label}
                  </th>
                ))}
                <th className="py-6 text-right text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] pl-4">Status</th>
              </tr>
            </thead>
            <tbody>
              {filteredClassrooms.map(cls => {
                const latestRecord = records
                  .filter(r => r.nama_kelas === cls.name)
                  .sort((a, b) => b.minggu - a.minggu)[0];
                
                const score = latestRecord?.markah || 0;
                const isLow = score < 70;
                const isExcellent = score >= 90;

                return (
                  <tr key={cls.id} className="border-b border-slate-50 hover:bg-slate-50/50 transition-colors group">
                    <td className="py-6 pr-4">
                      <p className="text-sm font-black text-slate-800 uppercase leading-none mb-1 group-hover:text-indigo-600 transition-colors">{cls.name}</p>
                      <p className="text-[10px] font-bold text-slate-400 uppercase tracking-tighter">{cls.teacher}</p>
                    </td>
                    <td className="py-6 px-4 text-center">
                      <span className={`text-lg font-black ${isLow ? 'text-rose-500' : isExcellent ? 'text-emerald-500' : 'text-slate-700'}`}>
                        {score}%
                      </span>
                    </td>
                    {settings.criteria.map(c => {
                      const val = latestRecord?.detailedScores?.[c.id] || 0;
                      const percent = (val / c.max) * 100;
                      const isCritLow = percent < 70;
                      
                      return (
                        <td key={c.id} className="py-6 px-4 text-center">
                          <div className="flex flex-col items-center">
                            <span className={`text-sm font-black ${isCritLow ? 'text-rose-500' : 'text-slate-600'}`}>
                              {val}/{c.max}
                            </span>
                            <div className="w-12 h-1 bg-slate-100 rounded-full mt-1 overflow-hidden">
                              <div 
                                className={`h-full rounded-full ${isCritLow ? 'bg-rose-400' : 'bg-indigo-400'}`} 
                                style={{ width: `${percent}%` }}
                              ></div>
                            </div>
                          </div>
                        </td>
                      );
                    })}
                    <td className="py-6 pl-4 text-right">
                      {isLow ? (
                        <span className="inline-flex items-center gap-1 text-[9px] font-black text-rose-500 uppercase tracking-widest bg-rose-50 px-3 py-1.5 rounded-lg border border-rose-100">
                          Perlu Baiki
                        </span>
                      ) : isExcellent ? (
                        <span className="inline-flex items-center gap-1 text-[9px] font-black text-emerald-600 uppercase tracking-widest bg-emerald-50 px-3 py-1.5 rounded-lg border border-emerald-100">
                          Cemerlang
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 text-[9px] font-black text-indigo-500 uppercase tracking-widest bg-indigo-50 px-3 py-1.5 rounded-lg border border-indigo-100">
                          Stabil
                        </span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
        
        {filteredClassrooms.length === 0 && (
          <div className="py-20 text-center">
            <p className="text-slate-400 font-bold uppercase tracking-widest text-xs">Tiada data kelas Sesi {currentSession} untuk dipaparkan.</p>
          </div>
        )}
      </section>
    </div>
  );
};

export default Dashboard;
