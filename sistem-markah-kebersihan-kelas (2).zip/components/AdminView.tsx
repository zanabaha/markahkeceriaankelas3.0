
import React, { useState } from 'react';
import { Classroom } from '../types';
import { bulkParseData } from '../services/geminiService';

interface AdminViewProps {
  classrooms: Classroom[];
  onUpdateClassrooms: (updated: Classroom[]) => void;
  schoolName: string;
  onUpdateSchoolName: (name: string) => void;
}

const AdminView: React.FC<AdminViewProps> = ({ classrooms, onUpdateClassrooms, schoolName, onUpdateSchoolName }) => {
  const [bulkText, setBulkText] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [activeSubTab, setActiveSubTab] = useState<'bulk' | 'overview' | 'settings'>('bulk');

  const handleBulkImport = async () => {
    if (!bulkText.trim()) return;
    setIsProcessing(true);
    
    const parsedData = await bulkParseData(bulkText);
    
    if (parsedData && Array.isArray(parsedData)) {
      // Fix: Add missing 'session' property to satisfy Classroom interface
      const newClassrooms: Classroom[] = parsedData.map((item: any, idx: number) => ({
        id: `class-${Date.now()}-${idx}-${Math.random()}`,
        name: item.name,
        teacher: item.teacher,
        session: 'Pagi', // Default session assigned to satisfy Classroom interface requirements
        students: item.students,
        scores: []
      }));
      
      onUpdateClassrooms([...classrooms, ...newClassrooms]);
      alert(`Berjaya! ${newClassrooms.length} kelas sekolah baru telah dimasukkan.`);
      setBulkText('');
      setActiveSubTab('overview');
    } else {
      alert("AI gagal memproses maklumat. Sila pastikan format teks anda mengandungi Nama Kelas dan Guru.");
    }
    setIsProcessing(false);
  };

  const handleClearAll = () => {
    if (confirm('⚠️ AMARAN KRITIKAL: Boss mahu PADAM SEMUA data (termasuk rekod markah dan nama demo) secara kekal? Sila pastikan boss benar-benar mahu mulakan dari kosong.')) {
      onUpdateClassrooms([]);
      localStorage.setItem('keceriaan_pro_v6_data', JSON.stringify([]));
      alert('Sistem telah dibersihkan sepenuhnya. Sila masukkan data sekolah boss sekarang.');
      setBulkText('');
      setActiveSubTab('bulk');
    }
  };

  const stats = {
    classes: classrooms.length,
    teachers: new Set(classrooms.map(c => c.teacher)).size,
    students: classrooms.reduce((acc, curr) => acc + curr.students.length, 0)
  };

  return (
    <div className="space-y-8 pb-20">
      {/* School Setup Wizard Header */}
      <div className="bg-white p-10 rounded-[40px] border border-slate-100 shadow-sm flex flex-col md:flex-row items-center justify-between gap-8">
         <div className="flex items-center space-x-6">
            <div className="w-20 h-20 bg-indigo-600 rounded-[30px] flex items-center justify-center text-white shadow-2xl shadow-indigo-100">
               <svg className="w-10 h-10" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" /></svg>
            </div>
            <div>
               <h3 className="text-3xl font-black text-slate-800 tracking-tight uppercase">{schoolName}</h3>
               <p className="text-slate-400 font-bold text-sm">Status: {classrooms.length > 0 ? 'Aktif' : 'Belum Berdaftar'}</p>
            </div>
         </div>
         <div className="flex space-x-4">
            <button 
               onClick={() => setActiveSubTab('settings')}
               className="bg-slate-100 text-slate-600 px-8 py-4 rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-slate-200 transition-all"
            >
               Tukar Nama Sekolah
            </button>
            <button 
               onClick={handleClearAll}
               className="bg-rose-50 text-rose-600 px-8 py-4 rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-rose-100 transition-all border border-rose-100"
            >
               Master Reset
            </button>
         </div>
      </div>

      {/* Sub Tabs */}
      <div className="flex bg-white p-2 rounded-2xl shadow-sm border border-slate-100 w-fit">
        {[
          { id: 'bulk', label: '🚀 Pendaftaran Pukal (AI)' },
          { id: 'overview', label: 'Senarai Murid & Guru' },
          { id: 'settings', label: '⚙️ Tetapan' }
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveSubTab(tab.id as any)}
            className={`px-8 py-4 rounded-xl text-[10px] font-black tracking-widest transition-all ${
              activeSubTab === tab.id ? 'bg-indigo-600 text-white shadow-xl shadow-indigo-100' : 'text-slate-400 hover:text-slate-600'
            }`}
          >
            {tab.label.toUpperCase()}
          </button>
        ))}
      </div>

      {activeSubTab === 'settings' && (
        <div className="bg-white p-12 rounded-[40px] border border-slate-100 shadow-sm animate-in fade-in slide-in-from-bottom-2">
           <div className="max-w-md">
              <label className="block text-xs font-black text-slate-400 uppercase tracking-[0.2em] mb-4">Urus Nama Sekolah Rasmi</label>
              <input 
                 type="text"
                 value={schoolName}
                 onChange={(e) => onUpdateSchoolName(e.target.value.toUpperCase())}
                 className="w-full p-6 bg-slate-50 border border-slate-200 rounded-[24px] font-black text-slate-800 text-2xl focus:ring-8 focus:ring-indigo-50 outline-none transition-all"
                 placeholder="Cth: SK BUKIT DAMANSARA"
              />
              <div className="mt-6 p-4 bg-indigo-50 rounded-2xl flex items-start space-x-3">
                 <svg className="w-5 h-5 text-indigo-500 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                 <p className="text-xs font-bold text-indigo-900 leading-relaxed uppercase opacity-70">Nama ini akan dipaparkan pada semua Sijil Kemenangan dan Dashboard utama.</p>
              </div>
           </div>
        </div>
      )}

      {activeSubTab === 'bulk' && (
        <div className="bg-white p-12 rounded-[40px] border border-slate-100 shadow-sm animate-in fade-in zoom-in-95 duration-500">
          <div className="flex items-start space-x-6 mb-10">
            <div className="w-16 h-16 bg-indigo-600 rounded-3xl flex items-center justify-center text-white shrink-0 shadow-2xl">
               <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M9 13h6m-3-3v6m5 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>
            </div>
            <div>
              <h3 className="text-3xl font-black text-slate-800 tracking-tight">MUAT NAIK PUKAL GUNA AI</h3>
              <p className="text-slate-500 mt-1 font-bold text-sm">Paste sahaja senarai kelas & guru dari WhatsApp atau Excel. AI kami akan susunkan.</p>
            </div>
          </div>

          <textarea
            value={bulkText}
            onChange={(e) => setBulkText(e.target.value)}
            placeholder="CONTOH INPUT:&#10;1. 6 Jaya - Cikgu Halim&#10;2. 5 Cekap - Cikgu Rozita&#10;3. 4 Maju - Cikgu Siti..."
            className="w-full h-80 p-10 bg-slate-50 border border-slate-100 rounded-[40px] outline-none focus:ring-8 focus:ring-indigo-50 font-bold text-slate-700 leading-relaxed shadow-inner transition-all placeholder:opacity-30"
          />

          <div className="mt-10 flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="flex items-center space-x-3 text-emerald-600">
               <div className="w-3 h-3 bg-emerald-500 rounded-full animate-ping"></div>
               <span className="text-[10px] font-black uppercase tracking-widest">Enjin AI Gemini Sedia Berkhidmat</span>
            </div>
            <button
              onClick={handleBulkImport}
              disabled={isProcessing || !bulkText.trim()}
              className="w-full md:w-auto px-16 py-6 bg-indigo-600 text-white font-black rounded-[24px] hover:bg-indigo-700 disabled:bg-slate-100 transition-all shadow-2xl shadow-indigo-100 active:scale-95 uppercase tracking-widest text-sm"
            >
              {isProcessing ? "AI SEDANG MENYUSUN..." : "SAHKAN & SIMPAN DATA BARU"}
            </button>
          </div>
        </div>
      )}

      {activeSubTab === 'overview' && (
        <div className="space-y-6 animate-in fade-in slide-in-from-bottom-2 duration-500">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white p-10 rounded-[30px] border border-slate-100 shadow-sm text-center">
              <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">JUMLAH KELAS</p>
              <p className="text-5xl font-black text-slate-800">{stats.classes}</p>
            </div>
            <div className="bg-white p-10 rounded-[30px] border border-slate-100 shadow-sm text-center">
              <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">GURU BERDAFTAR</p>
              <p className="text-5xl font-black text-indigo-600">{stats.teachers}</p>
            </div>
            <div className="bg-white p-10 rounded-[30px] border border-slate-100 shadow-sm text-center">
              <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">PELAJAR TERLIBAT</p>
              <p className="text-5xl font-black text-emerald-600">{stats.students}</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminView;
