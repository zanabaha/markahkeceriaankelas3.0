
import React, { useState } from 'react';
import { Classroom, ClassRecord } from '../types';
import { Award, Gift, Search, Crown, CheckCircle2, Filter } from 'lucide-react';
import CertificateView from './CertificateView';
import VoucherView from './VoucherView';

interface AwardCenterProps {
  classrooms: Classroom[];
  records: ClassRecord[];
  schoolName: string;
  customVoucherUrl?: string | null;
}

const AwardCenter: React.FC<AwardCenterProps> = ({ classrooms, records, schoolName, customVoucherUrl }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [onlyGradeA, setOnlyGradeA] = useState(true);
  const [selectedCert, setSelectedCert] = useState<{ name: string, teacher: string, score: number, week: number, category: string } | null>(null);
  const [selectedVoucher, setSelectedVoucher] = useState<{ name: string } | null>(null);

  const getLatestRecord = (className: string) => {
    const classRecords = records.filter(r => r.nama_kelas === className);
    if (classRecords.length === 0) return null;
    const latestWeek = Math.max(...classRecords.map(r => r.minggu));
    return classRecords.find(r => r.minggu === latestWeek) || null;
  };

  const filteredClasses = classrooms.filter(c => {
    const record = getLatestRecord(c.name);
    const score = record?.markah || 0;
    const matchesSearch = c.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                         c.teacher.toLowerCase().includes(searchTerm.toLowerCase());
    const isGradeA = score >= 80;
    
    if (onlyGradeA) return matchesSearch && isGradeA;
    return matchesSearch;
  });

  return (
    <div className="space-y-10 animate-in fade-in duration-500">
      {selectedCert && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-slate-900/95 backdrop-blur-xl">
           <CertificateView 
             schoolName={schoolName} 
             className={selectedCert.name} 
             teacherName={selectedCert.teacher} 
             score={selectedCert.score} 
             week={selectedCert.week}
             category={selectedCert.category}
             onClose={() => setSelectedCert(null)} 
           />
        </div>
      )}
      {selectedVoucher && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-slate-900/95 backdrop-blur-xl">
           <VoucherView 
             schoolName={schoolName} 
             className={selectedVoucher.name} 
             rewardName="JAMUAN KELAS / HADIAH" 
             customVoucherUrl={customVoucherUrl}
             onClose={() => setSelectedVoucher(null)} 
           />
        </div>
      )}

      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
        <div>
          <h2 className="text-4xl font-black text-slate-800 tracking-tighter uppercase leading-none">Pemenang <span className="text-indigo-600">Kelas Terbaik A</span></h2>
          <p className="text-slate-400 font-bold text-xs uppercase tracking-widest mt-2">Senarai Kelas Cemerlang (Markah 80% ke atas)</p>
        </div>
        
        <div className="flex flex-wrap gap-3">
          <button 
            onClick={() => setOnlyGradeA(!onlyGradeA)}
            className={`flex items-center gap-2 px-6 py-4 rounded-2xl font-black text-[10px] uppercase tracking-widest transition-all ${onlyGradeA ? 'bg-amber-500 text-white shadow-xl' : 'bg-white text-slate-400 border border-slate-100'}`}
          >
            <Filter size={14} /> {onlyGradeA ? 'Gred A Sahaja' : 'Semua Gred'}
          </button>
          <div className="relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
            <input type="text" placeholder="Cari kelas..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} className="pl-12 pr-6 py-4 bg-white rounded-2xl border border-slate-100 shadow-sm outline-none font-bold text-slate-600 text-xs uppercase" />
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredClasses.map(cls => {
          const record = getLatestRecord(cls.name);
          const score = record?.markah || 0;
          const isGradeA = score >= 80;
          
          return (
            <div key={cls.id} className={`bg-white p-8 rounded-[40px] border shadow-sm transition-all group ${isGradeA ? 'border-amber-200 ring-2 ring-amber-50' : 'border-slate-100'}`}>
              <div className="flex justify-between items-start mb-6">
                <div className={`w-14 h-14 rounded-2xl flex items-center justify-center shadow-lg ${isGradeA ? 'bg-amber-500 text-white' : 'bg-slate-100 text-slate-300'}`}>
                  <Crown size={28} />
                </div>
                <p className={`text-2xl font-black ${isGradeA ? 'text-amber-500' : 'text-slate-200'}`}>{score}%</p>
              </div>

              <h3 className="text-2xl font-black text-slate-800 uppercase leading-none mb-1">{cls.name}</h3>
              <p className="text-[10px] font-black text-slate-400 uppercase mb-8">{cls.teacher}</p>

              <div className="grid grid-cols-2 gap-3">
                <button 
                  onClick={() => setSelectedCert({ 
                    name: cls.name, 
                    teacher: cls.teacher, 
                    score: score,
                    week: record?.minggu || 0,
                    category: record?.kategori || 'UMUM'
                  })} 
                  className="bg-indigo-600 text-white py-4 rounded-2xl font-black text-[10px] uppercase shadow-xl hover:bg-indigo-700 transition-all"
                >
                  Sijil Terbaik
                </button>
                <button onClick={() => setSelectedVoucher({ name: cls.name })} className="bg-amber-100 text-amber-700 py-4 rounded-2xl font-black text-[10px] uppercase hover:bg-amber-500 hover:text-white transition-all">Hadiah Ganjaran</button>
              </div>
            </div>
          );
        })}
        {filteredClasses.length === 0 && (
           <div className="col-span-full py-20 text-center bg-slate-50 rounded-[40px] border-2 border-dashed border-slate-200">
              <CheckCircle2 size={48} className="mx-auto text-slate-200 mb-4" />
              <p className="text-slate-400 font-black text-[10px] uppercase tracking-widest">Tiada kelas mencapai Gred A minggu ini.</p>
           </div>
        )}
      </div>
    </div>
  );
};

export default AwardCenter;
