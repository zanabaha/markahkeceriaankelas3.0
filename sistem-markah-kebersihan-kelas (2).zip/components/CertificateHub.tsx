
import React, { useState } from 'react';
import { Classroom, ClassRecord } from '../types';
import { Award, Gift, Search, LayoutGrid, List, ChevronRight, Star, Crown } from 'lucide-react';
import CertificateView from './CertificateView';
import VoucherView from './VoucherView';

interface CertificateHubProps {
  classrooms: Classroom[];
  records: ClassRecord[];
  schoolName: string;
}

const CertificateHub: React.FC<CertificateHubProps> = ({ classrooms, records, schoolName }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCert, setSelectedCert] = useState<{ name: string, teacher: string, score: number } | null>(null);
  const [selectedVoucher, setSelectedVoucher] = useState<{ name: string } | null>(null);

  const filteredClasses = classrooms.filter(c => 
    c.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
    c.teacher.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getLatestScore = (className: string) => {
    const classRecords = records.filter(r => r.nama_kelas === className);
    if (classRecords.length === 0) return 0;
    const latestWeek = Math.max(...classRecords.map(r => r.minggu));
    return classRecords.find(r => r.minggu === latestWeek)?.markah || 0;
  };

  return (
    <div className="space-y-10 animate-in fade-in duration-500">
      {/* Modal Overlays */}
      {selectedCert && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-slate-900/95 backdrop-blur-xl">
           <CertificateView schoolName={schoolName} className={selectedCert.name} teacherName={selectedCert.teacher} score={selectedCert.score} onClose={() => setSelectedCert(null)} />
        </div>
      )}
      {selectedVoucher && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-slate-900/95 backdrop-blur-xl">
           <VoucherView schoolName={schoolName} className={selectedVoucher.name} rewardName="JAMUAN KELAS / HADIAH" onClose={() => setSelectedVoucher(null)} />
        </div>
      )}

      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <h2 className="text-4xl font-black text-slate-800 tracking-tighter uppercase leading-none">Hab <span className="text-indigo-600">Sijil & Baucar</span></h2>
          <p className="text-slate-400 font-bold text-xs uppercase tracking-widest mt-2">Iktiraf Kecemerlangan Kelas Dengan Pantas</p>
        </div>
        <div className="relative w-full md:w-80">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
          <input 
            type="text" 
            placeholder="Cari kelas atau guru..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-12 pr-6 py-4 bg-white rounded-2xl border border-slate-100 shadow-sm focus:ring-4 focus:ring-indigo-50 outline-none font-bold text-slate-600"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredClasses.map(cls => {
          const score = getLatestScore(cls.name);
          const hasScore = score > 0;
          
          return (
            <div key={cls.id} className="bg-white p-8 rounded-[40px] border border-slate-100 shadow-sm hover:shadow-xl transition-all group">
              <div className="flex justify-between items-start mb-6">
                <div className={`w-14 h-14 rounded-2xl flex items-center justify-center shadow-lg ${hasScore ? 'bg-indigo-600 text-white' : 'bg-slate-100 text-slate-300'}`}>
                  <Crown size={28} />
                </div>
                <div className="text-right">
                  <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Markah Terkini</p>
                  <p className={`text-2xl font-black ${hasScore ? 'text-indigo-600' : 'text-slate-200'}`}>{score}%</p>
                </div>
              </div>

              <h3 className="text-2xl font-black text-slate-800 uppercase tracking-tight mb-1">{cls.name}</h3>
              <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-8">{cls.teacher}</p>

              <div className="grid grid-cols-2 gap-3">
                <button 
                  onClick={() => setSelectedCert({ name: cls.name, teacher: cls.teacher, score: score })}
                  className="flex items-center justify-center gap-2 bg-indigo-50 text-indigo-600 py-4 rounded-2xl font-black text-[10px] uppercase tracking-widest hover:bg-indigo-600 hover:text-white transition-all shadow-sm"
                >
                  <Award size={16} /> Sijil
                </button>
                <button 
                  onClick={() => setSelectedVoucher({ name: cls.name })}
                  className="flex items-center justify-center gap-2 bg-amber-50 text-amber-600 py-4 rounded-2xl font-black text-[10px] uppercase tracking-widest hover:bg-amber-500 hover:text-white transition-all shadow-sm"
                >
                  <Gift size={16} /> Baucar
                </button>
              </div>
            </div>
          );
        })}
        {filteredClasses.length === 0 && (
          <div className="col-span-full py-20 text-center bg-slate-50 rounded-[40px] border-2 border-dashed border-slate-200">
             <Star size={48} className="mx-auto text-slate-200 mb-4" />
             <p className="text-slate-400 font-black text-[10px] uppercase tracking-widest">Tiada kelas ditemui. Sila setup data kelas di bahagian Admin.</p>
          </div>
        )}
      </div>
      
      <div className="bg-indigo-900 rounded-[40px] p-10 text-white relative overflow-hidden shadow-2xl">
         <div className="absolute right-0 top-0 p-10 opacity-10"><Award size={200} /></div>
         <div className="relative z-10 max-w-xl">
            <h3 className="text-2xl font-black uppercase tracking-tight mb-4">Tips Penjanaan</h3>
            <ul className="space-y-3 text-indigo-100 font-bold text-sm">
               <li className="flex items-center gap-3"><div className="w-1.5 h-1.5 bg-amber-400 rounded-full"></div> Sijil akan menggunakan markah dari penilaian minggu paling terkini secara automatik.</li>
               <li className="flex items-center gap-3"><div className="w-1.5 h-1.5 bg-amber-400 rounded-full"></div> Baucar dijana 3 keping dalam satu kertas A4 untuk memudahkan edaran kepada murid.</li>
               <li className="flex items-center gap-3"><div className="w-1.5 h-1.5 bg-amber-400 rounded-full"></div> Cikgu boleh muat naik design sendiri (custom) di dalam panel pralihat sijil/baucar.</li>
            </ul>
         </div>
      </div>
    </div>
  );
};

export default CertificateHub;
