
import React, { useRef, useState } from 'react';
import html2canvas from 'html2canvas';
import { jsPDF } from 'jspdf';
import { Download, Image as ImageIcon, Upload, Check, Trash2, Gift, Printer, X, RefreshCw } from 'lucide-react';

interface VoucherViewProps {
  schoolName: string;
  className: string;
  rewardName: string;
  customVoucherUrl?: string | null;
  onClose: () => void;
}

const VOUCHER_TEMPLATES = [
  { id: 1, url: 'https://i.ibb.co/L90P8N5/v1.png', label: 'Neon Reward' },
  { id: 2, url: 'https://i.ibb.co/hZ7XG6v/v2.png', label: 'Eco Green' },
  { id: 3, url: 'https://i.ibb.co/zH8XG6v/v3.png', label: 'Royal Gold' }
];

const VoucherView: React.FC<VoucherViewProps> = ({ schoolName, className, rewardName: initialReward, customVoucherUrl, onClose }) => {
  const printRef = useRef<HTMLDivElement>(null);
  const [selectedTemplate, setSelectedTemplate] = useState(customVoucherUrl || VOUCHER_TEMPLATES[0].url);
  const [isPrinting, setIsPrinting] = useState(false);
  const [reward, setReward] = useState(initialReward || "JAMUAN PIZZA KELAS");

  const downloadPDF = async () => {
    if (!printRef.current) return;
    setIsPrinting(true);
    
    // Small delay to ensure state update for printing (removing scale etc)
    setTimeout(async () => {
      try {
        const canvas = await html2canvas(printRef.current!, { 
          scale: 2, 
          useCORS: true,
          logging: false,
          backgroundColor: '#ffffff'
        });
        const imgData = canvas.toDataURL('image/png');
        const pdf = new jsPDF('p', 'mm', 'a4');
        const pdfWidth = pdf.internal.pageSize.getWidth();
        const pdfHeight = pdf.internal.pageSize.getHeight();
        pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight);
        pdf.save(`BAUCAR_GANJARAN_${className.replace(/\s+/g, '_')}.pdf`);
      } catch (err) {
        console.error("Print failed:", err);
        alert("Gagal menjana PDF. Sila cuba lagi.");
      } finally {
        setIsPrinting(false);
      }
    }, 100);
  };

  const handleUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const res = event.target?.result as string;
        setSelectedTemplate(res);
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="flex flex-col lg:flex-row gap-8 p-6 lg:p-10 max-h-[90vh] overflow-y-auto no-scrollbar bg-slate-900 rounded-[40px]">
      {/* Sidebar Controls */}
      <div className="lg:w-80 space-y-6 no-print">
        <div className="bg-white/10 backdrop-blur-xl p-6 rounded-[32px] border border-white/10">
          <h3 className="text-white font-black text-xs uppercase tracking-widest mb-6 flex items-center gap-2">
            <Gift size={16} className="text-amber-400" />
            Tetapan Baucar
          </h3>
          
          <div className="space-y-4 mb-8">
            <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest">Jenis Ganjaran</label>
            <input 
              type="text" 
              value={reward} 
              onChange={(e) => setReward(e.target.value.toUpperCase())}
              className="w-full bg-white/5 border border-white/10 p-3 rounded-xl text-white font-bold text-sm focus:ring-2 focus:ring-amber-500 outline-none"
              placeholder="CONTOH: JAMUAN KELAS"
            />
          </div>

          <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-3">Pilih Design</label>
          <div className="grid grid-cols-2 gap-2 mb-6">
            {customVoucherUrl && (
              <button 
                onClick={() => setSelectedTemplate(customVoucherUrl)} 
                className={`relative aspect-[2/1] rounded-lg overflow-hidden border-2 transition-all ${selectedTemplate === customVoucherUrl ? 'border-amber-500' : 'border-white/5 grayscale'}`}
              >
                <img src={customVoucherUrl} className="w-full h-full object-cover" alt="Custom" />
                <div className="absolute bottom-0 left-0 right-0 bg-amber-500 text-[6px] font-black text-white text-center py-0.5">CUSTOM</div>
              </button>
            )}
            {VOUCHER_TEMPLATES.map((t) => (
              <button key={t.id} onClick={() => setSelectedTemplate(t.url)} className={`relative aspect-[2/1] rounded-lg overflow-hidden border-2 transition-all ${selectedTemplate === t.url ? 'border-amber-500' : 'border-white/5 grayscale'}`}>
                <img src={t.url} className="w-full h-full object-cover" alt={t.label} />
              </button>
            ))}
            <label className="relative aspect-[2/1] rounded-lg overflow-hidden border-2 border-dashed border-white/20 flex items-center justify-center cursor-pointer hover:bg-white/5">
              <Upload size={16} className="text-white/40" />
              <input type="file" className="hidden" accept="image/*" onChange={handleUpload} />
            </label>
          </div>
        </div>

        <button 
          onClick={downloadPDF} 
          disabled={isPrinting}
          className="w-full bg-amber-500 text-amber-950 py-5 rounded-[24px] font-black text-xs uppercase tracking-widest shadow-2xl hover:bg-amber-400 transition-all flex items-center justify-center gap-3 disabled:opacity-50"
        >
          {isPrinting ? <RefreshCw className="animate-spin" size={18} /> : <Printer size={18} />}
          {isPrinting ? 'SEDANG MENJANA...' : 'CETAK A4 (3 PER PAGE)'}
        </button>
        <button onClick={onClose} className="w-full bg-white/5 text-white/40 py-4 rounded-[24px] font-black text-[10px] uppercase tracking-widest hover:bg-white/10 transition-all">Tutup</button>
      </div>

      {/* Preview Area (Simulating A4) */}
      <div className="flex-1 flex flex-col items-center">
        <div 
          className={`bg-white shadow-2xl origin-top ${isPrinting ? 'scale-100' : 'scale-[0.4] sm:scale-[0.5] md:scale-[0.6] lg:scale-[0.7] xl:scale-[0.8]'}`} 
          style={{ width: '210mm', height: '297mm' }} 
          ref={printRef}
        >
          {/* We generate 3 vouchers on one A4 sheet */}
          {[1, 2, 3].map((v) => (
            <div key={v} className="relative w-full h-[99mm] border-b border-dashed border-slate-200 overflow-hidden flex items-center justify-center p-8">
              <div 
                className="w-full h-full rounded-[20px] shadow-sm relative overflow-hidden"
                style={{ backgroundImage: `url(${selectedTemplate})`, backgroundSize: 'cover', backgroundPosition: 'center' }}
              >
                <div className="absolute inset-0 flex flex-col items-center justify-center text-center p-12 pointer-events-none">
                  <p className="text-sm font-black text-amber-900/50 uppercase tracking-[0.4em] mb-2">{schoolName}</p>
                  <h2 className="text-4xl font-black text-slate-900 uppercase tracking-tighter mb-1">BAUCAR GANJARAN</h2>
                  <div className="w-16 h-1 bg-amber-500 mb-6"></div>
                  
                  <div className="space-y-1 mb-6">
                    <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Dianugerahkan Kepada:</p>
                    <h3 className="text-3xl font-black text-indigo-900 uppercase">{className}</h3>
                  </div>

                  <div className="bg-white/80 backdrop-blur-md px-10 py-4 rounded-full border border-amber-200 shadow-xl">
                    <p className="text-[9px] font-black text-amber-600 uppercase tracking-widest mb-1">PENEBUSAN HADIAH</p>
                    <p className="text-xl font-black text-slate-800">{reward}</p>
                  </div>

                  <p className="absolute bottom-6 right-8 text-[8px] font-black text-slate-400 uppercase tracking-[0.3em]">designbycikguzana</p>
                </div>
              </div>
            </div>
          ))}
        </div>
        <p className="mt-6 text-white/30 text-[10px] font-black uppercase tracking-widest">Susunan 3 keping baucar secara automatik untuk saiz A4</p>
      </div>
    </div>
  );
};

export default VoucherView;
