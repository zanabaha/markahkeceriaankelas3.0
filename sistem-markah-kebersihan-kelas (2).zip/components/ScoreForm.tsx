
import React, { useState } from 'react';
import { Classroom, ScoreCriteria } from '../types';
import { CRITERIA_LIMITS } from '../constants';

interface ScoreFormProps {
  classrooms: Classroom[];
  onSave: (classId: string, criteria: ScoreCriteria) => void;
}

const ScoreForm: React.FC<ScoreFormProps> = ({ classrooms, onSave }) => {
  const [selectedClass, setSelectedClass] = useState<string>('');
  const [marks, setMarks] = useState<ScoreCriteria>({
    kebersihan: 0,
    susunAtur: 0,
    papanMaklumat: 0,
    kreativiti: 0,
    keselamatan: 0,
    lestari: 0
  });

  const handleInputChange = (key: keyof ScoreCriteria, value: string) => {
    // Fix: Cast key to string to resolve indexing issues with CRITERIA_LIMITS
    const numValue = Math.min(Math.max(0, Number(value)), CRITERIA_LIMITS[key as string]);
    setMarks(prev => ({ ...prev, [key]: numValue }));
  };

  // Explicitly sum numeric properties to ensure 'total' is correctly typed as 'number'
  // This avoids inference issues that can occur with Object.values and reduce in some TypeScript environments.
  const total = marks.kebersihan + marks.susunAtur + marks.papanMaklumat + marks.kreativiti + marks.keselamatan + marks.lestari;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedClass) return alert('Sila pilih kelas!');
    onSave(selectedClass, marks);
    alert('Markah berjaya disimpan!');
    setMarks({ kebersihan: 0, susunAtur: 0, papanMaklumat: 0, kreativiti: 0, keselamatan: 0, lestari: 0 });
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div className="bg-white p-8 rounded-3xl shadow-sm border border-slate-100">
        <div className="flex items-center space-x-4 mb-8">
          <div className="w-12 h-12 bg-indigo-100 text-indigo-600 rounded-2xl flex items-center justify-center">
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" /></svg>
          </div>
          <div>
            <h2 className="text-2xl font-black text-slate-800">Borang Penilaian Mingguan</h2>
            <p className="text-sm text-slate-500">Sila masukkan markah bagi setiap kriteria (Jumlah Keseluruhan: 100%).</p>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-8">
          <div className="bg-slate-50 p-6 rounded-2xl">
            <label className="block text-xs font-black text-slate-400 uppercase tracking-widest mb-3">Pilih Kelas Untuk Dinilai</label>
            <select 
              className="w-full p-4 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none font-bold text-slate-700 shadow-sm transition-all"
              value={selectedClass}
              onChange={(e) => setSelectedClass(e.target.value)}
            >
              <option value="">-- Pilih Nama Kelas --</option>
              {classrooms.map(c => (
                <option key={c.id} value={c.id}>{c.name} - {c.teacher}</option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Kategori Utama */}
            <div className="space-y-4">
              <h4 className="text-xs font-black text-slate-400 uppercase tracking-widest flex items-center space-x-2">
                <span className="w-2 h-2 bg-indigo-500 rounded-full"></span>
                <span>Aspek Kebersihan & Fizikal</span>
              </h4>
              <div className="space-y-4">
                {[
                  { id: 'kebersihan', label: 'Kebersihan Keseluruhan', max: 25 },
                  { id: 'susunAtur', label: 'Susun Atur Perabot', max: 15 },
                  { id: 'keselamatan', label: 'Ciri-ciri Keselamatan', max: 10 }
                ].map(item => (
                  <div key={item.id} className="bg-white border border-slate-100 p-4 rounded-2xl hover:border-indigo-200 transition-colors">
                    <div className="flex justify-between items-center mb-2">
                      <label className="text-sm font-bold text-slate-700">{item.label}</label>
                      <span className="text-[10px] font-black text-slate-400">MAX {item.max}</span>
                    </div>
                    <input 
                      type="number"
                      value={marks[item.id as keyof ScoreCriteria]}
                      onChange={(e) => handleInputChange(item.id as keyof ScoreCriteria, e.target.value)}
                      className="w-full p-3 bg-slate-50 border-none rounded-xl focus:ring-2 focus:ring-indigo-500 font-black text-slate-800 text-lg"
                      placeholder="0"
                    />
                  </div>
                ))}
              </div>
            </div>

            {/* Kategori Kreativiti & Lestari */}
            <div className="space-y-4">
              <h4 className="text-xs font-black text-slate-400 uppercase tracking-widest flex items-center space-x-2">
                <span className="w-2 h-2 bg-emerald-500 rounded-full"></span>
                <span>Inovasi & Kelestarian</span>
              </h4>
              <div className="space-y-4">
                {[
                  { id: 'lestari', label: 'Lestari & Inisiatif Hijau', max: 20, highlight: true },
                  { id: 'papanMaklumat', label: 'Papan Maklumat & Info', max: 15 },
                  { id: 'kreativiti', label: 'Kreativiti & Estetika', max: 15 }
                ].map(item => (
                  <div key={item.id} className={`p-4 rounded-2xl transition-colors border ${item.highlight ? 'bg-emerald-50 border-emerald-100' : 'bg-white border-slate-100 hover:border-emerald-200'}`}>
                    <div className="flex justify-between items-center mb-2">
                      <label className={`text-sm font-bold ${item.highlight ? 'text-emerald-700' : 'text-slate-700'}`}>{item.label}</label>
                      <span className="text-[10px] font-black text-slate-400">MAX {item.max}</span>
                    </div>
                    <input 
                      type="number"
                      value={marks[item.id as keyof ScoreCriteria]}
                      onChange={(e) => handleInputChange(item.id as keyof ScoreCriteria, e.target.value)}
                      className={`w-full p-3 border-none rounded-xl focus:ring-2 focus:ring-emerald-500 font-black text-lg ${item.highlight ? 'bg-white text-emerald-700' : 'bg-slate-50 text-slate-800'}`}
                      placeholder="0"
                    />
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="pt-8 border-t border-slate-100 flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="flex items-center space-x-6">
              <div className="bg-indigo-600 px-8 py-4 rounded-3xl text-white shadow-xl shadow-indigo-100">
                <p className="text-[10px] font-black uppercase tracking-widest opacity-70">Jumlah Skor</p>
                <div className="flex items-baseline space-x-1">
                  <span className="text-4xl font-black">{total}</span>
                  <span className="text-lg font-bold opacity-70">%</span>
                </div>
              </div>
              <div className="hidden md:block">
                <p className="text-xs font-bold text-slate-400 uppercase tracking-tighter">Status Penilaian</p>
                <p className={`text-sm font-black ${total >= 80 ? 'text-emerald-500' : total >= 50 ? 'text-amber-500' : 'text-rose-500'}`}>
                  {total >= 80 ? 'Sangat Cemerlang' : total >= 50 ? 'Memuaskan' : 'Perlu Usaha'}
                </p>
              </div>
            </div>
            
            <button 
              type="submit"
              className="w-full md:w-auto px-12 py-5 bg-indigo-600 text-white font-black rounded-2xl hover:bg-indigo-700 transition-all shadow-xl shadow-indigo-100 active:scale-95"
            >
              SAHKAN & SIMPAN MARKAH
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default ScoreForm;
