
import React, { useState, useEffect } from 'react';
import { ClassRecord, DutyTeacherList, Classroom, Criterion } from '../types';
import { StorageService } from '../services/storage';
import { Sun, Moon, Star, Lock, Save, HelpCircle } from 'lucide-react';
import { generateId } from '../utils';

interface RecordEntryProps {
  onUpdate: () => void;
  records: ClassRecord[];
  dutyTeachers: DutyTeacherList;
  classrooms: Classroom[];
}

const RecordEntry: React.FC<RecordEntryProps> = ({ onUpdate, records, dutyTeachers, classrooms }) => {
  const [settings] = useState(StorageService.getCertSettings());
  const [currentSession, setCurrentSession] = useState<'Pagi' | 'Petang' | 'PPKI'>('Pagi');
  const [quickMinggu, setQuickMinggu] = useState<string>(localStorage.getItem('smkk_last_minggu') || '1');
  const [quickTarikh, setQuickTarikh] = useState<string>(new Date().toISOString().split('T')[0]);
  const [quickGuru, setQuickGuru] = useState<string>('');
  const [quickData, setQuickData] = useState<Record<string, Record<string, number>>>({});
  const [lockedClasses, setLockedClasses] = useState<Set<string>>(new Set());

  const criteria = settings.criteria;
  const filteredClassrooms = classrooms.filter(c => c.session === currentSession);

  useEffect(() => {
    const initialData: Record<string, Record<string, number>> = {};
    const newLocked = new Set<string>();
    const weekNum = parseInt(quickMinggu);

    filteredClassrooms.forEach(cls => {
      const criteriaMap: Record<string, number> = {};
      criteria.forEach(c => criteriaMap[c.id] = 0);

      const existing = records.find(r => r.nama_kelas === cls.name && r.minggu === weekNum);
      if (existing) {
        if (existing.markah > 0) newLocked.add(cls.name);
        criteria.forEach(c => {
          criteriaMap[c.id] = existing.detailedScores?.[c.id] || 0;
        });
      }
      initialData[cls.name] = criteriaMap;
    });

    setQuickData(initialData);
    setLockedClasses(newLocked);
  }, [currentSession, quickMinggu, records, classrooms, criteria]);

  const handleQuickChange = (className: string, criteriaId: string, value: string, max: number) => {
    let val = parseInt(value) || 0;
    val = Math.min(Math.max(0, val), max);
    setQuickData(prev => ({
      ...prev,
      [className]: { ...prev[className], [criteriaId]: val }
    }));
  };

  const calculateQuickTotal = (className: string): number => {
    const scores = quickData[className];
    if (!scores) return 0;
    // Fix: Explicitly type the return value of reduce as a number using a generic to avoid 'unknown' assignment errors
    return Object.values(scores).reduce<number>((a, b) => a + (b as number), 0);
  };

  const handleQuickSave = () => {
    if (!quickMinggu || !quickGuru) return alert("Sila isi Minggu dan Guru Bertugas.");
    const weekNum = parseInt(quickMinggu);
    let count = 0;

    filteredClassrooms.forEach(cls => {
      if (lockedClasses.has(cls.name)) return;
      const scores = quickData[cls.name];
      const total = calculateQuickTotal(cls.name);
      
      // Check if total is greater than 0 to save the record
      if (total > 0) {
        const existing = records.find(r => r.nama_kelas === cls.name && r.minggu === weekNum);
        const record: ClassRecord = {
          id: existing?.id || generateId(),
          nama_kelas: cls.name,
          markah: total,
          minggu: weekNum,
          tarikh: quickTarikh,
          kategori: cls.session,
          guru_bertugas: quickGuru,
          catatan: existing?.catatan || '',
          detailedScores: scores,
        };
        StorageService.saveRecord(record);
        count++;
      }
    });
    
    localStorage.setItem('smkk_last_minggu', quickMinggu);
    onUpdate();
    alert(`Berjaya simpan markah bagi ${count} kelas Sesi ${currentSession}.`);
  };

  return (
    <div className="space-y-6">
      <div className="bg-white p-6 rounded-[32px] shadow-sm border border-slate-100 grid grid-cols-1 md:grid-cols-3 gap-6">
        <div>
          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 block">Minggu Persekolahan</label>
          <input type="number" value={quickMinggu} onChange={e => setQuickMinggu(e.target.value)} className="w-full p-4 bg-slate-50 rounded-2xl border-none font-black text-slate-700" />
        </div>
        <div>
          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 block">Tarikh Penilaian</label>
          <input type="date" value={quickTarikh} onChange={e => setQuickTarikh(e.target.value)} className="w-full p-4 bg-slate-50 rounded-2xl border-none font-black text-slate-700" />
        </div>
        <div>
          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 block">Guru Bertugas</label>
          <select value={quickGuru} onChange={e => setQuickGuru(e.target.value)} className="w-full p-4 bg-slate-50 rounded-2xl border-none font-black text-slate-700">
            <option value="">Pilih Guru</option>
            {Object.values(dutyTeachers).map(t => <option key={t} value={t}>{t}</option>)}
          </select>
        </div>
      </div>

      <div className="flex flex-wrap gap-2">
        {['Pagi', 'Petang', 'PPKI'].map((id) => (
          <button 
            key={id} 
            onClick={() => setCurrentSession(id as any)} 
            className={`px-8 py-5 rounded-2xl font-black text-[10px] uppercase tracking-widest transition-all ${currentSession === id ? 'bg-indigo-600 text-white shadow-xl shadow-indigo-100' : 'bg-white text-slate-400'}`}
          >
            Sesi {id}
          </button>
        ))}
      </div>

      <div className="bg-white rounded-[40px] shadow-sm border border-slate-100 overflow-hidden">
        <div className="p-8 border-b border-slate-50 flex flex-col md:flex-row justify-between items-center gap-4 bg-slate-50/30">
           <h3 className="font-black text-slate-800 uppercase tracking-widest text-xs">Jadual Markah: Sesi {currentSession}</h3>
           <button onClick={handleQuickSave} className="bg-emerald-600 text-white px-10 py-4 rounded-2xl font-black text-[10px] uppercase tracking-widest shadow-xl">Simpan Semua {currentSession}</button>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-slate-50 text-[9px] font-black text-slate-400 uppercase border-b">
              <tr>
                <th className="p-6 sticky left-0 bg-slate-50 z-10">Nama Kelas</th>
                {criteria.map(c => <th key={c.id} className="p-4 text-center min-w-[120px]">{c.label}<br/><span className="opacity-40 font-bold">MAX {c.max}</span></th>)}
                <th className="p-6 text-center bg-indigo-50 text-indigo-600">Jumlah</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {filteredClassrooms.map(cls => (
                <tr key={cls.id} className={`${lockedClasses.has(cls.name) ? 'bg-emerald-50/30' : ''}`}>
                  <td className="p-6 font-black text-slate-700 sticky left-0 bg-white z-10 border-r">
                    <div className="flex items-center gap-2">
                      {cls.name}
                      {lockedClasses.has(cls.name) && <Lock size={12} className="text-emerald-500" />}
                    </div>
                  </td>
                  {criteria.map(c => (
                    <td key={c.id} className="p-2 text-center">
                      <input 
                        type="number" 
                        disabled={lockedClasses.has(cls.name)}
                        className={`w-14 h-12 text-center rounded-xl font-black text-lg ${lockedClasses.has(cls.name) ? 'bg-transparent text-slate-300' : 'bg-slate-50 text-slate-700 shadow-inner'}`}
                        value={quickData[cls.name]?.[c.id] || 0}
                        onChange={e => handleQuickChange(cls.name, c.id, e.target.value, c.max)}
                      />
                    </td>
                  ))}
                  <td className="p-6 text-center font-black text-2xl text-indigo-600 bg-indigo-50/30">
                    {calculateQuickTotal(cls.name)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default RecordEntry;
