
import React, { useState, useEffect } from 'react';
import * as XLSX from 'xlsx';
import { Upload, Trash2, School, Save, Plus, GraduationCap, Layout, FileSpreadsheet, Settings2, CheckCircle, AlertTriangle, Table, Image as ImageIcon, X, UserCheck, ClipboardList, Sparkles, RefreshCw, Download } from 'lucide-react';
import { Classroom, DutyTeacherList, CertificateSettings, Criterion } from '../types';
import { StorageService } from '../services/storage';
import { GoogleGenAI, Type } from "@google/genai";

interface TeachersProps {
  onUpdate: () => void;
}

const Teachers: React.FC<TeachersProps> = ({ onUpdate }) => {
  const [settings, setSettings] = useState<CertificateSettings>(StorageService.getCertSettings());
  const [classrooms, setClassrooms] = useState<Classroom[]>(StorageService.getClassrooms());
  const [activeSubTab, setActiveSubTab] = useState<'profile' | 'classes' | 'criteria' | 'duty'>('classes');
  const [isSaving, setIsSaving] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [dutyInput, setDutyInput] = useState('');
  const [classInput, setClassInput] = useState('');

  useEffect(() => {
    const savedDuty = StorageService.getDutyTeachers();
    setDutyInput(Object.values(savedDuty).join('\n'));
    
    const savedClasses = StorageService.getClassrooms();
    // Format: Guru, Kelas
    setClassInput(savedClasses.map(c => `${c.teacher}, ${c.name}`).join('\n'));
    setClassrooms(savedClasses);
  }, []);

  const downloadDesignGuide = () => {
    const canvas = document.createElement('canvas');
    canvas.width = 1123;
    canvas.height = 794;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Background
    ctx.fillStyle = 'white';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Border
    ctx.strokeStyle = '#ef4444';
    ctx.setLineDash([10, 10]);
    ctx.lineWidth = 2;
    ctx.strokeRect(20, 20, canvas.width - 40, canvas.height - 40);

    // Title
    ctx.setLineDash([]);
    ctx.fillStyle = 'black';
    ctx.font = '900 24px Arial';
    ctx.fillText('TAPAK DESIGN SIJIL (1123px x 794px)', 40, 60);

    // Instructions
    ctx.font = '400 14px Arial';
    ctx.fillText('1. Design background anda di Canva.', 40, 90);
    ctx.fillText('2. KOTAK MERAH adalah tempat sistem akan letak tulisan secara automatik.', 40, 110);
    ctx.fillText('3. Kosongkan kawasan kotak merah dalam design anda.', 40, 130);

    // Helper function for boxes
    const drawBox = (x: number, y: number, w: number, h: number, label: string, color = '#fee2e2', textColor = '#b91c1c') => {
      ctx.fillStyle = color;
      ctx.fillRect(x, y, w, h);
      ctx.strokeStyle = '#f87171';
      ctx.strokeRect(x, y, w, h);
      ctx.fillStyle = textColor;
      ctx.font = '900 16px Arial';
      ctx.textAlign = 'center';
      ctx.fillText(label, x + w / 2, y + h / 2 + 6);
      
      ctx.font = '400 10px Arial';
      ctx.fillText('Kawasan ini akan diisi oleh sistem', x + w / 2, y + h / 2 + 25);
    };

    // Header Area
    drawBox(160, 80, 800, 200, 'RUANG HEADER / TAJUK / LOGO (Design Sendiri)', '#f1f5f9', '#475569');

    // Nama Kelas
    drawBox(210, 340, 700, 100, 'NAMA KELAS (System)');

    // Kategori & Minggu
    drawBox(310, 450, 500, 40, 'KATEGORI & MINGGU (System)');

    // Markah
    drawBox(260, 520, 600, 100, 'MARKAH - GRED - PERATUS (System)');

    // Tarikh
    ctx.textAlign = 'left';
    drawBox(40, 650, 250, 80, 'TARIKH & BINTANG (System)');

    // Tandatangan
    ctx.textAlign = 'right';
    drawBox(canvas.width - 360, 640, 300, 100, 'TANDATANGAN PENGETUA (System)');

    // Center Line
    ctx.strokeStyle = '#3b82f6';
    ctx.setLineDash([5, 5]);
    ctx.beginPath();
    ctx.moveTo(canvas.width / 2, 0);
    ctx.lineTo(canvas.width / 2, canvas.height);
    ctx.stroke();

    // Watermark
    ctx.setLineDash([]);
    ctx.fillStyle = '#94a3b8';
    ctx.font = '900 10px Arial';
    ctx.textAlign = 'center';
    ctx.fillText('DESIGNBYCIKGUZANA', canvas.width / 2, canvas.height - 10);

    const link = document.createElement('a');
    link.download = 'TAPAK_DESIGN_SIJIL_GUIDE.png';
    link.href = canvas.toDataURL();
    link.click();
  };

  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>, key: 'logo2' | 'logoBadge' | 'logo3' | 'customCertificateUrl' | 'customVoucherUrl') => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const result = event.target?.result as string;
        const newSettings = { ...settings, [key]: result };
        setSettings(newSettings);
        StorageService.saveCertSettings(newSettings);
        onUpdate();
      };
      reader.readAsDataURL(file);
    }
  };

  const handleDeleteLogo = (e: React.MouseEvent, key: 'logo2' | 'logoBadge' | 'logo3' | 'customCertificateUrl' | 'customVoucherUrl') => {
    e.preventDefault();
    e.stopPropagation();
    if (confirm('Adakah anda pasti mahu memadam logo/template ini?')) {
      const newSettings = { ...settings, [key]: null };
      setSettings(newSettings);
      StorageService.saveCertSettings(newSettings);
      onUpdate();
    }
  };

  const downloadVoucherGuide = () => {
    const canvas = document.createElement('canvas');
    canvas.width = 794; // 210mm
    canvas.height = 374; // 99mm
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.fillStyle = 'white';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    ctx.strokeStyle = '#f59e0b';
    ctx.setLineDash([10, 10]);
    ctx.lineWidth = 2;
    ctx.strokeRect(10, 10, canvas.width - 20, canvas.height - 20);

    ctx.setLineDash([]);
    ctx.fillStyle = 'black';
    ctx.font = '900 20px Arial';
    ctx.textAlign = 'center';
    ctx.fillText('TAPAK DESIGN BAUCAR (794px x 374px)', canvas.width / 2, 40);

    const drawBox = (x: number, y: number, w: number, h: number, label: string) => {
      ctx.fillStyle = '#fef3c7';
      ctx.fillRect(x, y, w, h);
      ctx.strokeStyle = '#fbbf24';
      ctx.strokeRect(x, y, w, h);
      ctx.fillStyle = '#92400e';
      ctx.font = '900 14px Arial';
      ctx.textAlign = 'center';
      ctx.fillText(label, x + w / 2, y + h / 2 + 5);
    };

    drawBox(50, 80, 200, 200, 'LOGO / GAMBAR');
    drawBox(270, 100, 450, 60, 'NAMA KELAS (System)');
    drawBox(270, 180, 450, 80, 'JENIS GANJARAN (System)');

    const link = document.createElement('a');
    link.download = 'TAPAK_DESIGN_BAUCAR_GUIDE.png';
    link.href = canvas.toDataURL();
    link.click();
  };
  const downloadExcelTemplate = () => {
    const data = [
      { 'NAMA GURU': 'CIKGU AZIZAH', 'NAMA KELAS': '3 ARIF' },
      { 'NAMA GURU': 'USTAZAH SITI', 'NAMA KELAS': '5 BESTARI' },
      { 'NAMA GURU': 'CIKGU HALIM', 'NAMA KELAS': '4 CEKAP' },
    ];
    const ws = XLSX.utils.json_to_sheet(data);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Template');
    XLSX.writeFile(wb, 'Template_Keceriaan_Kelas.xlsx');
  };

  const handleExcelImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (evt) => {
      try {
        const bstr = evt.target?.result;
        const wb = XLSX.read(bstr, { type: 'binary' });
        const ws = wb.Sheets[wb.SheetNames[0]];
        const data: any[] = XLSX.utils.sheet_to_json(ws);
        
        const importedLines = data.map(row => {
          const teacher = (row['NAMA GURU'] || row['Guru'] || "").toString().trim();
          const name = (row['NAMA KELAS'] || row['Kelas'] || "").toString().trim();
          return (teacher && name) ? `${teacher}, ${name}` : null;
        }).filter(Boolean);

        setClassInput(prev => (prev ? prev + '\n' : '') + importedLines.join('\n'));
        alert("Data Excel berjaya dimasukkan! Sila semak senarai di bawah dan tekan SIMPAN.");
      } catch (err) {
        alert("Gagal baca Excel. Pastikan lajur bertajuk 'NAMA GURU' dan 'NAMA KELAS'.");
      }
    };
    reader.readAsBinaryString(file);
  };

  const handleSaveAll = () => {
    setIsSaving(true);
    StorageService.saveCertSettings(settings);

    // Format: Guru, Kelas
    const newClassrooms: Classroom[] = classInput.split('\n')
      .filter(line => line.trim())
      .map((line, idx) => {
        const parts = line.split(',').map(s => s.trim().toUpperCase());
        const teacher = parts[0] || 'TIADA GURU';
        const name = parts[1] || 'KELAS TANPA NAMA';
        
        // Detect session: 1-2 Petang, 3-5 Pagi
        let session: 'Pagi' | 'Petang' = 'Pagi';
        const firstChar = name.trim().charAt(0);
        if (name.includes('PETANG') || firstChar === '1' || firstChar === '2') {
          session = 'Petang';
        } else if (firstChar === '3' || firstChar === '4' || firstChar === '5') {
          session = 'Pagi';
        }

        return {
          id: `cls-${Date.now()}-${idx}`,
          name: name,
          teacher: teacher,
          session: session,
          scores: []
        };
      });
    StorageService.saveClassrooms(newClassrooms);
    setClassrooms(newClassrooms);

    const newDutyList: DutyTeacherList = {};
    dutyInput.split('\n').filter(name => name.trim()).forEach((name, index) => {
      newDutyList[index] = name.trim().toUpperCase();
    });
    StorageService.saveDutyTeachers(newDutyList);

    onUpdate();
    setTimeout(() => {
      setIsSaving(false);
      alert("Tahniah! Semua maklumat kelas dan sistem telah dikemaskini.");
    }, 500);
  };

  const handleSmartGenerateIdentity = async () => {
    setIsGenerating(true);
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    
    const prompt = `Bertindak sebagai pakar branding sekolah kreatif. Berikan 1 nama sistem yang pendek & catchy (cth: CERIA-X, SMART-K), 1 tajuk utama dan 1 slogan untuk "Sistem Pemarkahan Keceriaan Kelas" sekolah ${settings.schoolName}. Berikan output dalam JSON.`;

    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              systemName: { type: Type.STRING },
              heroTitle: { type: Type.STRING },
              heroSlogan: { type: Type.STRING }
            },
            required: ["systemName", "heroTitle", "heroSlogan"]
          }
        }
      });
      const data = JSON.parse(response.text || '{}');
      setSettings(prev => ({ 
        ...prev, 
        systemName: data.systemName.toUpperCase(),
        heroTitle: data.heroTitle.toUpperCase(),
        heroSlogan: data.heroSlogan
      }));
    } catch (e) {
      alert("Gagal menjana idea AI. Sila semak sambungan internet.");
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="space-y-8 pb-24 animate-in fade-in duration-500">
      <div className="bg-indigo-950 text-white p-10 rounded-[40px] shadow-2xl relative overflow-hidden">
        <div className="absolute right-0 top-0 p-10 opacity-10 rotate-12"><Settings2 size={180} /></div>
        <div className="relative z-10">
          <h2 className="text-3xl font-black uppercase tracking-tighter mb-2">PENGURUSAN SISTEM</h2>
          <p className="text-indigo-400 font-bold text-xs uppercase tracking-widest">Konfigurasi kelas, guru, dan identiti sekolah anda.</p>
        </div>
      </div>

      <div className="flex bg-white p-2 rounded-[30px] shadow-sm border border-slate-100 overflow-x-auto no-scrollbar">
        {[
          { id: 'classes', label: '1. Daftar Guru & Kelas', icon: GraduationCap },
          { id: 'duty', label: '2. Guru Bertugas', icon: UserCheck },
          { id: 'criteria', label: '3. Kriteria Markah', icon: ClipboardList },
          { id: 'profile', label: '4. Identiti & Template', icon: School },
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveSubTab(tab.id as any)}
            className={`flex items-center gap-3 px-8 py-5 rounded-[22px] font-black text-[11px] uppercase tracking-widest transition-all whitespace-nowrap ${
              activeSubTab === tab.id ? 'bg-indigo-600 text-white shadow-xl' : 'text-slate-400 hover:text-slate-600'
            }`}
          >
            <tab.icon size={16} />
            {tab.label}
          </button>
        ))}
      </div>

      <div className="bg-white rounded-[50px] p-12 shadow-sm border border-slate-100 min-h-[500px]">
        
        {activeSubTab === 'classes' && (
          <div className="space-y-8 animate-in slide-in-from-bottom-4">
             <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                <div>
                   <h3 className="text-2xl font-black text-slate-800 uppercase tracking-tight">Daftar Guru & Kelas</h3>
                   <p className="text-slate-400 font-bold text-xs mt-1 uppercase">Susunan: <span className="text-indigo-600">NAMA GURU, NAMA KELAS</span></p>
                </div>
                <div className="flex gap-2">
                   <button onClick={downloadExcelTemplate} className="bg-slate-100 text-slate-600 px-5 py-3 rounded-xl font-black text-[10px] uppercase tracking-widest flex items-center gap-2 hover:bg-slate-200">
                      <Download size={14} /> Template Excel
                   </button>
                   <label className="bg-indigo-50 text-indigo-600 px-5 py-3 rounded-xl font-black text-[10px] uppercase tracking-widest cursor-pointer hover:bg-indigo-100 flex items-center gap-2">
                      <Upload size={14} /> Import Excel
                      <input type="file" className="hidden" accept=".xlsx,.xls" onChange={handleExcelImport} />
                   </label>
                </div>
             </div>
             <textarea 
               value={classInput}
               onChange={(e) => setClassInput(e.target.value)}
               placeholder="CIKGU AZIZAH, 3 ARIF&#10;USTAZAH SITI, 5 BESTARI"
               className="w-full h-96 bg-slate-50 rounded-[35px] p-10 font-black text-slate-700 leading-relaxed border-none focus:ring-8 focus:ring-indigo-50 outline-none shadow-inner"
             />
          </div>
        )}

        {activeSubTab === 'duty' && (
          <div className="space-y-8 animate-in slide-in-from-bottom-4">
             <div>
                <h3 className="text-2xl font-black text-slate-800 uppercase tracking-tight">Senarai Guru Penilai (Hakim)</h3>
                <p className="text-slate-400 font-bold text-xs mt-1 uppercase">Masukkan nama guru bertugas untuk penilaian minggu ini.</p>
             </div>
             <textarea 
               value={dutyInput}
               onChange={(e) => setDutyInput(e.target.value)}
               placeholder="CIKGU AMINAH&#10;CIKGU ROSLI"
               className="w-full h-96 bg-slate-50 rounded-[35px] p-10 font-black text-slate-700 leading-relaxed border-none focus:ring-8 focus:ring-emerald-50 outline-none shadow-inner"
             />
          </div>
        )}

        {activeSubTab === 'profile' && (
          <div className="space-y-12 animate-in slide-in-from-bottom-4">
             <div className="grid lg:grid-cols-2 gap-12">
                <div className="space-y-8">
                   <div className="flex items-center justify-between">
                      <h3 className="text-2xl font-black text-slate-800 uppercase tracking-tight">Branding & AI</h3>
                      <button 
                        onClick={handleSmartGenerateIdentity}
                        disabled={isGenerating}
                        className="bg-amber-100 text-amber-700 px-4 py-2 rounded-xl font-black text-[10px] uppercase tracking-widest flex items-center gap-2 hover:bg-amber-200 transition-all"
                      >
                        {isGenerating ? <RefreshCw className="animate-spin" size={14} /> : <Sparkles size={14} />}
                        Jana Idea AI ✨
                      </button>
                   </div>
                   <div className="grid grid-cols-1 gap-6">
                      <div>
                         <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 block">Nama Aplikasi (App Name)</label>
                         <input type="text" className="w-full p-5 bg-slate-50 rounded-2xl font-black text-slate-800 text-xl border-none" value={settings.systemName} onChange={e => setSettings({...settings, systemName: e.target.value.toUpperCase()})} />
                      </div>
                      <div>
                         <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 block">Tajuk Utama (Hero Title)</label>
                         <input type="text" className="w-full p-5 bg-slate-50 rounded-2xl font-black text-slate-800 text-xl border-none" value={settings.heroTitle} onChange={e => setSettings({...settings, heroTitle: e.target.value.toUpperCase()})} />
                      </div>
                      <div>
                         <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 block">Nama Sekolah Rasmi</label>
                         <input type="text" className="w-full p-5 bg-slate-50 rounded-2xl font-black text-slate-800 text-xl border-none" value={settings.schoolName} onChange={e => setSettings({...settings, schoolName: e.target.value.toUpperCase()})} />
                      </div>
                      <div>
                         <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 block">Slogan Visi</label>
                         <textarea rows={2} className="w-full p-5 bg-slate-50 rounded-2xl font-bold text-slate-600 border-none resize-none" value={settings.heroSlogan} onChange={e => setSettings({...settings, heroSlogan: e.target.value})} />
                      </div>
                      <div>
                         <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 block">Link Google Drive (Laporan/Gambar)</label>
                         <input type="text" className="w-full p-5 bg-slate-50 rounded-2xl font-bold text-indigo-600 border-none" placeholder="https://drive.google.com/..." value={settings.reportsDriveUrl} onChange={e => setSettings({...settings, reportsDriveUrl: e.target.value})} />
                      </div>
                   </div>
                </div>

                <div className="space-y-8">
                   <h3 className="text-2xl font-black text-slate-800 uppercase tracking-tight">Template & Logo</h3>
                   <div className="bg-slate-50 p-8 rounded-[40px] border border-slate-100">
                        <div className="mb-8 bg-indigo-50 p-6 rounded-3xl border border-indigo-100">
                           <h4 className="text-sm font-black text-indigo-900 uppercase mb-2 flex items-center gap-2">
                              <Layout size={18} /> Panduan Design Canva
                           </h4>
                           <p className="text-[11px] text-indigo-700 font-bold leading-relaxed mb-4">
                              Muat turun tapak di bawah sebagai rujukan kedudukan tulisan automatik sistem. Gunakan saiz yang dinyatakan di Canva.
                           </p>
                           <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                              <button 
                                onClick={downloadDesignGuide}
                                className="bg-indigo-600 text-white px-4 py-4 rounded-2xl font-black text-[10px] uppercase tracking-widest flex items-center justify-center gap-2 hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-200"
                              >
                                <Download size={16} /> Tapak Sijil (1123x794)
                              </button>
                              <button 
                                onClick={downloadVoucherGuide}
                                className="bg-amber-500 text-white px-4 py-4 rounded-2xl font-black text-[10px] uppercase tracking-widest flex items-center justify-center gap-2 hover:bg-amber-600 transition-all shadow-lg shadow-amber-200"
                              >
                                <Download size={16} /> Tapak Baucar (794x374)
                              </button>
                           </div>
                        </div>
                      <div className="relative group mb-6">
                        <label className="w-full h-48 bg-white rounded-3xl border-2 border-dashed border-slate-200 flex flex-col items-center justify-center cursor-pointer hover:border-indigo-400 overflow-hidden relative">
                           {settings.customCertificateUrl ? (
                              <div className="relative w-full h-full">
                                 <img src={settings.customCertificateUrl} className="w-full h-full object-cover" />
                                 <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity">
                                    <span className="text-white text-[10px] font-black uppercase">Tukar Template</span>
                                 </div>
                              </div>
                           ) : (
                              <div className="text-center">
                                 <ImageIcon className="text-slate-300 mx-auto mb-2" size={32} />
                                 <p className="text-[9px] font-black text-slate-400 uppercase">Upload Sijil Canva Anda</p>
                              </div>
                           )}
                           <input type="file" className="hidden" accept="image/*" onChange={(e) => handleLogoUpload(e, 'customCertificateUrl')} />
                        </label>
                        {settings.customCertificateUrl && (
                          <button 
                            onClick={(e) => handleDeleteLogo(e, 'customCertificateUrl')}
                            className="absolute -top-2 -right-2 bg-rose-500 text-white p-2 rounded-full shadow-lg hover:bg-rose-600 transition-all z-20"
                          >
                            <Trash2 size={14} />
                          </button>
                        )}
                      </div>

                      <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-4 block text-center">Logo Sekolah / Agensi</label>
                      <div className="grid grid-cols-3 gap-3 mb-8">
                        {['logo2', 'logoBadge', 'logo3'].map((key) => (
                          <div key={key} className="relative group">
                            <label className="aspect-square bg-white rounded-2xl border-2 border-dashed border-slate-200 flex flex-col items-center justify-center cursor-pointer hover:border-indigo-400 overflow-hidden relative">
                               {(settings as any)[key] ? <img src={(settings as any)[key]} className="w-full h-full object-contain p-2" /> : <Plus className="text-slate-300" />}
                               <input type="file" className="hidden" accept="image/*" onChange={(e) => handleLogoUpload(e, key as any)} />
                            </label>
                            {(settings as any)[key] && (
                              <button 
                                onClick={(e) => handleDeleteLogo(e, key as any)}
                                className="absolute -top-2 -right-2 bg-rose-500 text-white p-1.5 rounded-full shadow-lg hover:bg-rose-600 transition-all z-20"
                              >
                                <Trash2 size={10} />
                              </button>
                            )}
                          </div>
                        ))}
                      </div>

                      <div className="border-t border-slate-200 pt-8 mt-8">
                        <h4 className="text-sm font-black text-slate-800 uppercase tracking-tight mb-4">Tetapan Baucer Ganjaran</h4>
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-4 block text-center">Design Baucer Custom (Landscape)</label>
                        <div className="relative group">
                          <label className="w-full h-32 bg-white rounded-3xl border-2 border-dashed border-slate-200 flex flex-col items-center justify-center cursor-pointer hover:border-indigo-400 overflow-hidden relative">
                             {settings.customVoucherUrl ? (
                                <div className="relative w-full h-full">
                                   <img src={settings.customVoucherUrl} className="w-full h-full object-cover" />
                                   <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity">
                                      <span className="text-white text-[10px] font-black uppercase">Tukar Design</span>
                                   </div>
                                </div>
                             ) : (
                                <div className="text-center">
                                   <ImageIcon className="text-slate-300 mx-auto mb-2" size={24} />
                                   <p className="text-[9px] font-black text-slate-400 uppercase">Upload Design Baucer</p>
                                </div>
                             )}
                             <input type="file" className="hidden" accept="image/*" onChange={(e) => handleLogoUpload(e, 'customVoucherUrl')} />
                          </label>
                          {settings.customVoucherUrl && (
                            <button 
                              onClick={(e) => handleDeleteLogo(e, 'customVoucherUrl')}
                              className="absolute -top-2 -right-2 bg-rose-500 text-white p-2 rounded-full shadow-lg hover:bg-rose-600 transition-all z-20"
                            >
                              <Trash2 size={14} />
                            </button>
                          )}
                        </div>
                      </div>
                   </div>
                </div>
             </div>
          </div>
        )}

        {activeSubTab === 'criteria' && (
          <div className="space-y-8 animate-in slide-in-from-bottom-4">
             <div className="flex justify-between items-center">
                <h3 className="text-2xl font-black text-slate-800 uppercase tracking-tight">Kriteria Markah</h3>
                <button 
                  onClick={() => {
                    const newCriterion = { id: `c-${Date.now()}`, label: 'KRITERIA BARU', max: 10 };
                    setSettings({...settings, criteria: [...settings.criteria, newCriterion]});
                  }}
                  className="bg-indigo-600 text-white px-8 py-4 rounded-2xl font-black text-[10px] uppercase tracking-widest shadow-lg flex items-center gap-2"
                >
                  <Plus size={16} /> Tambah Kriteria
                </button>
             </div>
             <div className="space-y-4">
                {settings.criteria.map((c, idx) => (
                  <div key={c.id} className="grid grid-cols-1 md:grid-cols-12 gap-6 bg-slate-50 p-6 rounded-3xl items-center border border-slate-100">
                    <div className="md:col-span-1 text-center font-black text-indigo-500 text-xl">#{idx + 1}</div>
                    <div className="md:col-span-7">
                      <input type="text" className="w-full bg-white p-4 rounded-xl font-black text-slate-700 uppercase border-none focus:ring-2 focus:ring-indigo-500" value={c.label} onChange={e => {
                        const updated = [...settings.criteria];
                        updated[idx].label = e.target.value.toUpperCase();
                        setSettings({...settings, criteria: updated});
                      }} />
                    </div>
                    <div className="md:col-span-3">
                      <input type="number" className="w-full bg-white p-4 rounded-xl font-black text-slate-700 text-center border-none focus:ring-2 focus:ring-indigo-500" value={c.max} onChange={e => {
                        const updated = [...settings.criteria];
                        updated[idx].max = parseInt(e.target.value) || 0;
                        setSettings({...settings, criteria: updated});
                      }} />
                    </div>
                    <button onClick={() => setSettings({...settings, criteria: settings.criteria.filter(item => item.id !== c.id)})} className="md:col-span-1 text-slate-300 hover:text-rose-500"><Trash2 size={20} /></button>
                  </div>
                ))}
             </div>
          </div>
        )}
      </div>

      <div className="fixed bottom-10 left-1/2 -translate-x-1/2 z-50">
        <button 
          onClick={handleSaveAll}
          disabled={isSaving}
          className="bg-indigo-600 text-white px-16 py-6 rounded-full font-black text-sm uppercase tracking-[0.2em] shadow-2xl shadow-indigo-500/50 hover:bg-indigo-700 hover:scale-105 active:scale-95 transition-all flex items-center gap-4"
        >
          {isSaving ? <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div> : <Save size={20} />}
          {isSaving ? "SEDANG DISIMPAN..." : "SIMPAN SEMUA DATA"}
        </button>
      </div>
    </div>
  );
};

export default Teachers;
