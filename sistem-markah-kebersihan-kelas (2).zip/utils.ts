
export const getScoreColor = (score: number) => {
  if (score >= 45) return '#10b981'; // Emerald
  if (score >= 35) return '#3b82f6'; // Blue
  if (score >= 25) return '#f59e0b'; // Amber
  return '#ef4444'; // Red
};

export const getPercentage = (score: number, max: number = 50) => {
  return ((score / max) * 100).toFixed(1);
};

export const generateId = () => {
  return Math.random().toString(36).substr(2, 9);
};

export const getStars = (score: number) => {
  if (score >= 45) return '⭐⭐⭐⭐⭐';
  if (score >= 35) return '⭐⭐⭐⭐';
  if (score >= 25) return '⭐⭐⭐';
  return '⭐⭐';
};
