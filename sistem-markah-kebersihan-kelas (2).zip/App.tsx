
import React, { useEffect } from 'react';
import { Classroom, ViewType, ClassRecord, TeacherMap, DutyTeacherList } from './types';
import Home from './components/Home';
import Dashboard from './components/Dashboard';
import RecordEntry from './components/RecordEntry';
import ReportsView from './components/ReportsView';
import HistoryView from './components/HistoryView';
import Teachers from './components/Teachers';
import RankingView from './components/RankingView';
import AwardCenter from './components/AwardCenter';
import Navbar from './components/Navbar';
import { StorageService } from './services/storage';

const App: React.FC = () => {
  const [settings, setSettings] = React.useState(() => StorageService.getCertSettings());
  const [records, setRecords] = React.useState<ClassRecord[]>([]);
  const [classrooms, setClassrooms] = React.useState<Classroom[]>([]);
  const [dutyTeachers, setDutyTeachers] = React.useState<DutyTeacherList>({});
  const [activeTab, setActiveTab] = React.useState<ViewType>('home');

  useEffect(() => {
    refreshData();
  }, []);

  const refreshData = () => {
    const savedRecords = StorageService.getRecords();
    const savedClassrooms = StorageService.getClassrooms();
    const savedDuty = StorageService.getDutyTeachers();
    const savedSettings = StorageService.getCertSettings();

    const processedClassrooms = savedClassrooms.map(cls => ({
      ...cls,
      scores: savedRecords
        .filter(r => r.nama_kelas === cls.name)
        .map(r => ({
          week: r.minggu,
          date: r.tarikh,
          total: r.markah,
          marks: {
            // Fix: Access criteria scores from the detailedScores property using the correct IDs
            kebersihan: r.detailedScores?.['cermin_tingkap'] || 0, // Fallback to 0 if not found
            lestari: r.detailedScores?.['sudut_lestari'] || 0
          }
        }))
    }));

    setRecords(savedRecords);
    setClassrooms(processedClassrooms);
    setDutyTeachers(savedDuty);
    setSettings(savedSettings);
  };

  return (
    <div className="min-h-screen bg-[#f8fafc] flex flex-col no-scrollbar">
      <Navbar currentView={activeTab} onNavigate={setActiveTab} classrooms={classrooms} schoolName={settings.schoolName} />

      <main className="flex-1 p-4 md:p-10 lg:p-12 overflow-y-auto no-scrollbar">
        <div className="max-w-7xl mx-auto">
          {activeTab === 'home' && <Home classrooms={classrooms} records={records} onNavigate={setActiveTab} settings={settings} />}
          {activeTab === 'dashboard' && <Dashboard classrooms={classrooms} />}
          {activeTab === 'scoring' && <RecordEntry onUpdate={refreshData} records={records} dutyTeachers={dutyTeachers} classrooms={classrooms} />}
          {activeTab === 'history' && <HistoryView classrooms={classrooms} />}
          {activeTab === 'ai-tips' && <ReportsView classrooms={classrooms} settings={settings} />}
          {activeTab === 'ranking' && <RankingView records={records} schoolName={settings.schoolName} />}
          {activeTab === 'awards' && <AwardCenter classrooms={classrooms} records={records} schoolName={settings.schoolName} customVoucherUrl={settings.customVoucherUrl} />}
          {activeTab === 'management' && <Teachers onUpdate={refreshData} />}
        </div>
      </main>
    </div>
  );
};

export default App;
