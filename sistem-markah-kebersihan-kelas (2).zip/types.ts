
export type Category = 'ppki-pagi' | 'tingkatan1' | 'tingkatan2' | 'tingkatan3' | 'tingkatan4' | 'tingkatan5' | 'sesi-pagi' | 'sesi-petang';

export interface Criterion {
  id: string;
  label: string;
  max: number;
}

export interface ScoreCriteria {
  kebersihan: number;
  susunAtur: number;
  papanMaklumat: number;
  kreativiti: number;
  keselamatan: number;
  lestari: number;
}

export interface ClassRecord {
  id: string;
  nama_kelas: string;
  markah: number;
  minggu: number;
  tarikh: string;
  kategori: string;
  guru_bertugas: string;
  catatan: string;
  detailedScores: Record<string, number>;
}

export interface Classroom {
  id: string;
  name: string;
  teacher: string;
  session: 'Pagi' | 'Petang' | 'PPKI';
  scores: any[];
}

export interface CertificateSettings {
  schoolName: string;
  systemName: string; // Dynamic App Title
  heroTitle: string;
  heroSlogan: string;
  reportsDriveUrl: string;
  logoBadge: string | null;
  logo2: string | null;
  logo3: string | null;
  customCertificateUrl: string | null;
  customVoucherUrl: string | null;
  criteria: Criterion[];
}

export type ViewType = 'home' | 'dashboard' | 'scoring' | 'ranking' | 'ai-tips' | 'history' | 'management' | 'awards';
export type TeacherMap = Record<string, { teacher: string, session: 'Pagi' | 'Petang' | 'PPKI' }>;
export type DutyTeacherList = Record<number, string>;
