
import { GoogleGenAI, Type } from "@google/genai";
import { Classroom } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const getAITips = async (classroom: Classroom) => {
  const latestScore = classroom.scores[classroom.scores.length - 1];
  if (!latestScore) return null;

  const prompt = `
    Bertindak sebagai Pakar Perunding Keceriaan Bilik Darjah. 
    Analisis data prestasi untuk kelas "${classroom.name}" yang diajar oleh ${classroom.teacher}:
    - Kebersihan: ${latestScore.marks.kebersihan}/25
    - Lestari & Hijau: ${latestScore.marks.lestari}/20
    
    Berikan rumusan, 3 tips penambahbaikan, dan kata motivasi dalam format JSON.
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            analysis: { type: Type.STRING },
            tips: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  kriteria: { type: Type.STRING },
                  cadangan: { type: Type.STRING },
                },
                required: ["kriteria", "cadangan"],
              },
            },
            motivation: { type: Type.STRING }
          },
          required: ["analysis", "tips", "motivation"],
        },
      }
    });

    return JSON.parse(response.text || '{}');
  } catch (error) {
    console.error("Gemini AI Error:", error);
    return null;
  }
};

export const bulkParseData = async (rawText: string) => {
  const prompt = `
    Anda adalah pembantu pentadbiran sekolah.
    Tugas: Ekstrak maklumat kelas, guru, dan murid daripada teks mentah berikut.
    - Kenalpasti nama kelas (cth: 5 Ibnu Sina)
    - Kenalpasti nama guru kelas
    - Senaraikan murid bagi setiap kelas tersebut.
    
    Teks Mentah:
    ${rawText}
    
    Format Output (JSON Array):
    [
      {
        "name": "Nama Kelas",
        "teacher": "Nama Guru",
        "students": ["Murid 1", "Murid 2"]
      }
    ]
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: { responseMimeType: "application/json" }
    });
    return JSON.parse(response.text || '[]');
  } catch (error) {
    console.error("Bulk Parse Error:", error);
    return null;
  }
};
