
import { ClassRecord, DutyTeacherList, CertificateSettings, Classroom, Criterion } from '../types';

const STORAGE_KEY = 'keceriaan_pro_records_v3';
const DUTY_KEY = 'keceriaan_pro_duty';
const SETTINGS_KEY = 'keceriaan_pro_cert_settings';
const CLASSROOMS_KEY = 'keceriaan_pro_classrooms_data';

const DEFAULT_CRITERIA: Criterion[] = [
  { id: 'c1', label: 'Kebersihan Lantai', max: 10 },
  { id: 'c2', label: 'Susun Atur Meja', max: 10 },
  { id: 'c3', label: 'Papan Kenyataan', max: 10 },
  { id: 'c4', label: 'Sudut Bacaan', max: 10 },
  { id: 'c5', label: 'Kreativiti', max: 10 }
];

export const StorageService = {
  getRecords: (): ClassRecord[] => {
    const data = localStorage.getItem(STORAGE_KEY);
    if (!data) {
      const initialRecords: ClassRecord[] = [
        { id: 'r1', nama_kelas: '1 AL-FARABI', markah: 85, minggu: 1, tarikh: '2025-01-05', kategori: 'tingkatan1', guru_bertugas: 'CIKGU ZANA', catatan: '', detailedScores: { 'c1': 8, 'c2': 9, 'c3': 8, 'c4': 9, 'c5': 8 } },
        { id: 'r2', nama_kelas: '1 AL-GHAZALI', markah: 92, minggu: 1, tarikh: '2025-01-05', kategori: 'tingkatan1', guru_bertugas: 'CIKGU ZANA', catatan: '', detailedScores: { 'c1': 9, 'c2': 10, 'c3': 9, 'c4': 9, 'c5': 9 } },
        { id: 'r3', nama_kelas: '1 AL-FARABI', markah: 88, minggu: 2, tarikh: '2025-01-12', kategori: 'tingkatan1', guru_bertugas: 'CIKGU ALI', catatan: '', detailedScores: { 'c1': 9, 'c2': 9, 'c3': 8, 'c4': 9, 'c5': 9 } },
      ];
      localStorage.setItem(STORAGE_KEY, JSON.stringify(initialRecords));
      return initialRecords;
    }
    return JSON.parse(data);
  },

  saveRecord: (record: ClassRecord) => {
    const records = StorageService.getRecords();
    const index = records.findIndex(r => r.id === record.id);
    if (index > -1) {
      records[index] = record;
    } else {
      records.push(record);
    }
    localStorage.setItem(STORAGE_KEY, JSON.stringify(records));
  },

  getClassrooms: (): Classroom[] => {
    const data = localStorage.getItem(CLASSROOMS_KEY);
    if (!data) {
      const initialClassrooms: Classroom[] = [
        { id: '1', name: '1 AL-FARABI', teacher: 'CIKGU AHMAD', session: 'Pagi', scores: [] },
        { id: '2', name: '1 AL-GHAZALI', teacher: 'CIKGU SITI', session: 'Pagi', scores: [] },
        { id: '3', name: '2 AL-FARABI', teacher: 'CIKGU ZUL', session: 'Pagi', scores: [] },
        { id: '4', name: '2 AL-GHAZALI', teacher: 'CIKGU AMINAH', session: 'Pagi', scores: [] },
      ];
      localStorage.setItem(CLASSROOMS_KEY, JSON.stringify(initialClassrooms));
      return initialClassrooms;
    }
    return JSON.parse(data);
  },

  saveClassrooms: (classrooms: Classroom[]) => {
    localStorage.setItem(CLASSROOMS_KEY, JSON.stringify(classrooms));
  },

  getDutyTeachers: (): DutyTeacherList => {
    const data = localStorage.getItem(DUTY_KEY);
    return data ? JSON.parse(data) : {};
  },

  saveDutyTeachers: (list: DutyTeacherList) => {
    localStorage.setItem(DUTY_KEY, JSON.stringify(list));
  },

  getCertSettings: (): CertificateSettings => {
    const data = localStorage.getItem(SETTINGS_KEY);
    const defaults: CertificateSettings = {
      schoolName: 'SMK TINGGI KUALA LUMPUR',
      systemName: 'KECERIAAN PRO',
      heroTitle: 'Ekosistem Kelas Pintar',
      heroSlogan: 'Revolusi digital pengurusan kebersihan kelas.',
      reportsDriveUrl: '',
      logoBadge: null,
      logo2: null,
      logo3: null,
      customCertificateUrl: null,
      customVoucherUrl: null,
      criteria: DEFAULT_CRITERIA
    };
    return data ? { ...defaults, ...JSON.parse(data) } : defaults;
  },

  saveCertSettings: (settings: CertificateSettings) => {
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
  }
};
