
import { Category } from './types';

export const CLASS_CATEGORIES: Record<string, string> = {
  'ppki-pagi': 'PPKI (Zeta)',
  'tingkatan1': 'Tingkatan 1',
  'tingkatan2': 'Tingkatan 2',
  'tingkatan3': 'Tingkatan 3',
  'tingkatan4': 'Tingkatan 4',
  'tingkatan5': 'Tingkatan 5',
};

export const CLASS_LISTS: Record<string, string[]> = {
  'tingkatan1': ['1 ARIF', '1 BESTARI', '1 CEKAP', '1 DINAMIK', '1 ELIT'],
  'tingkatan2': ['2 ARIF', '2 BESTARI', '2 CEKAP', '2 DINAMIK', '2 ELIT'],
  'tingkatan3': ['3 ARIF', '3 BESTARI', '3 CEKAP', '3 DINAMIK', '3 ELIT'],
  'tingkatan4': ['4 ARIF', '4 BESTARI', '4 CEKAP', '4 DINAMIK', '4 ELIT'],
  'tingkatan5': ['5 ARIF', '5 BESTARI', '5 CEKAP', '5 DINAMIK', '5 ELIT'],
  'ppki-pagi': ['ZETA 1', 'ZETA 2', 'ZETA 3'],
};

export const CRITERIA_LIST = [
  { id: 'cermin_tingkap', label: 'Cermin', max: 4 },
  { id: 'lantai', label: 'Lantai', max: 5 },
  { id: 'papan_putih', label: 'Papan Putih', max: 4 },
  { id: 'meja_guru', label: 'Meja Guru', max: 4 },
  { id: 'meja_kerusi_pelajar', label: 'Meja Murid', max: 5 },
  { id: 'penyapu_bakul', label: 'Penyapu', max: 4 },
  { id: 'sudut_bacaan', label: 'Sudut Bacaan', max: 4 },
  { id: 'keseluruhan_kelas', label: 'Kekemasan', max: 5 },
  { id: 'papan_kenyataan', label: 'Kenyataan', max: 5 },
  { id: 'langsir', label: 'Langsir', max: 4 },
  { id: 'carta', label: 'Carta Organisasi', max: 3 },
  { id: 'sudut_lestari', label: 'Sudut Lestari', max: 3 },
];

/**
 * Added for compatibility with ScoreForm.tsx
 */
export const CRITERIA_LIMITS: Record<string, number> = {
  kebersihan: 25,
  susunAtur: 15,
  papanMaklumat: 15,
  kreativiti: 15,
  keselamatan: 10,
  lestari: 20
};

export const DUTY_TEACHERS = [
  'CIKGU NORAINI', 'CIKGU AZIZAH', 'CIKGU WAN MOHD', 'CIKGU ROSLI', 'CIKGU SITI AMINAH'
];

export const INITIAL_CLASSES = []; // Kosongkan untuk setup rasmi
